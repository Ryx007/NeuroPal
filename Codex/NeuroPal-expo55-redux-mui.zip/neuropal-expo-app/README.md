# NeuroPal

Cross-platform NeuroPal app rebuilt around Expo SDK 55, Expo Router, Redux Toolkit, Tailwind/NativeWind, and mandatory MUI support for web-only surfaces. The visual direction follows the attached NeuroPal HTML/wireframe files while keeping the app native-first for iOS and Android.

## What changed

- No `next.js`
- Expo 55 app for iOS, Android, and web
- Tailwind via `nativewind` and `global.css`
- MUI integrated through [src/providers/MuiProvider.web.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/src/providers/MuiProvider.web.tsx:1) and the web-specific [src/components/TweaksSheet.web.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/src/components/TweaksSheet.web.tsx:1)
- Redux Toolkit state with React Redux hooks via [src/store/hooks.ts](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/src/store/hooks.ts:1)
- Removed the old Zustand architecture

## Architecture

Key files:

- [app/_layout.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/app/_layout.tsx:1) wires fonts, providers, router, and the onboarding gate
- [src/providers/AppProviders.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/src/providers/AppProviders.tsx:1) hydrates and persists Redux state with `AsyncStorage`
- [src/store/index.ts](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/src/store/index.ts:1) configures the Redux store
- [src/store/selectors.ts](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/src/store/selectors.ts:1) centralizes derived state
- `src/store/slices/*` contains feature slices for onboarding, home, library, reader, and UI tweaks
- [app/(tabs)/reader.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/app/(tabs)/reader.tsx:1) now uses Redux for playback, chat, and reader controls

## State rules

All feature code now reads state with `useSelector` semantics through the typed `useAppSelector` wrapper and mutates state with `useDispatch` semantics through `useAppDispatch`.

Examples:

- onboarding: [app/onboarding.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/app/onboarding.tsx:1)
- home/dashboard: [app/(tabs)/index.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/app/(tabs)/index.tsx:1)
- library: [app/(tabs)/library.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/app/(tabs)/library.tsx:1)
- anchors/profile: [app/(tabs)/anchors.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/app/(tabs)/anchors.tsx:1), [app/(tabs)/profile.tsx](/Users/ryx/Documents/Gitkraken/App%20Dev/NeuroPal/Codex/neuropal-expo-app/app/(tabs)/profile.tsx:1)

## Platform notes

- iOS bundle ID: `io.neuropal.app`
- Android package: `io.neuropal.app`
- Expo Router drives the native/mobile navigation
- MUI is used on web-only components where React Native primitives are not the right fit
- Tailwind is available through `className` and NativeWind interop

## Run

```bash
cd neuropal-expo-app
npm install
npx expo start
```

Then run:

- `npx expo run:ios`
- `npx expo run:android`
- `npm run web`

## Important note

This environment does not include `npm`, so I could not run a full install or native/web build here. I updated the package versions to match current Expo SDK 55 documentation closely, but the next local step should still be `npx expo install --check` or `npx expo install --fix` after dependencies are available, so Expo can fully normalize the native package set.

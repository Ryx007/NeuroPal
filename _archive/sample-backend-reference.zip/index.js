const express = require('express')
const app = express();
const cors = require('cors');
const cluster = require('cluster');
const numCPUs = require('os').cpus().length;
const configs = require('./routes/app');
const leads = require('./routes/leads');
const customers = require('./routes/customers');
const users = require('./routes/users');
const services = require('./routes/services');
const template = require('./routes/template');
const invoice = require('./routes/invoice');
const cron = require('./routes/cron');
const settings = require('./routes/settings');
const wapi = require('./routes/wapi');
const accountant = require('./routes/accountant');
const company = require('./routes/company');
const stat = require('./routes/stat');
const connectDB = require('./libs/db');

if (cluster.isMaster) {
    console.log(`Master ${process.pid} is running`);
  
    // Fork workers
    for (let i = 0; i < numCPUs; i++) {
        cluster.fork();
    }
  
    cluster.on('exit', (worker, code, signal) => {
        console.log(`Worker ${worker.process.pid} died`);
        cluster.fork();
    });
} else {
    connectDB();
    
    const port = 4000;
    app.use(cors());
    app.use(express.json())
    app.use(express.urlencoded({ extended: true }));

    app.use((req, res, next) => {
        res.set('Cache-Control', 'no-store');
        next();
    });

    app.use('/app', configs);
    app.use('/leads', leads);
    app.use('/customers', customers);
    app.use('/services', services);
    app.use('/invoice', invoice);
    app.use('/template', template);
    app.use('/accountant', accountant);
    app.use('/users', users);
    app.use('/cron', cron);
    app.use('/settings', settings);
    app.use('/wapi', wapi);
    app.use('/company', company);
    app.use('/stat', stat);

    app.use((req, res, next) => {
        res.send({ status: false, message: 'Not Found' });
    });

    app.listen(port, console.log(`Server run and listening port: ${port}`));
}
const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');

const accountantJobsSchema = new mongoose.Schema({
    customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
    jobTitle: {type: String,required: true},
    created: { type: Date, default: Date.now},
    accountant: {type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true},
    expiryDate: {type: Date},
    status: { type: String, enum: ["Done", "Ongoing", "To Be Done"], default: "To Be Done", required: true},
    doneOn: { type: Date},
    compliance: {type: mongoose.Schema.Types.ObjectId, ref: 'Compliance'}
});
accountantJobsSchema.plugin(toJSON);
accountantJobsSchema.plugin(mongoosePaginate);
const AccountantJob = mongoose.model('AccountantJob', accountantJobsSchema);

module.exports = AccountantJob;
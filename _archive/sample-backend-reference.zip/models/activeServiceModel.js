const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const activeServiceSchema = new mongoose.Schema({
    customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
    status: { type: Boolean, default: true },
    start: { type: Date, default: Date.now },
    end: {type: Date}
});
activeServiceSchema.plugin(toJSON);
const ActiveService = mongoose.model('ActiveService', activeServiceSchema);

module.exports = ActiveService;
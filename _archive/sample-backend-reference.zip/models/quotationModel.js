const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');
const quotationModel = mongoose.Schema(
    {
        lead: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead' },
        customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
        price: {type: Number, default: 0},
        cgst: {type: Number, default: 0},
        igst: {type: Number, default: 0},
        sgst: {type: Number, default: 0},
        gst: {type: Number, default: 0},
        total: {type: Number, default: 0},
        created: {type: Date}
    }
)
quotationModel.plugin(mongoosePaginate);
quotationModel.plugin(toJSON);
const Quotation = mongoose.model("Quotation", quotationModel);
module.exports = Quotation;
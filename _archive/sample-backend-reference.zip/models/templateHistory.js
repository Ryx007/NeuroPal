const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');

const TemplateHistorySchema = new mongoose.Schema({
    lead: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead' },
    customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
    type: {type: String, enum: ["lead", "customer"], required: true},
    content: { type: String },
    template: { type: mongoose.Schema.Types.ObjectId, ref: 'EmailTemplate' },
    subject: { type: String },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    created: { type: Number, default: Date.now}
});

TemplateHistorySchema.plugin(toJSON);
TemplateHistorySchema.plugin(mongoosePaginate);
const TemplateHistory = mongoose.model('TemplateHistory', TemplateHistorySchema);
module.exports = TemplateHistory;

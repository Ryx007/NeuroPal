const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');
const recurringInvoiceSchema = mongoose.Schema(
    {
        customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
        startDate : {type: Date, required: true},
        endDate: {type: Date, required: true},
        nextDate: {type: Date, required: true},
        interval: {type: Number, required: true},
        intervalType: {type: String, enum: ["day", "month"], required: true},
        status: {type: Boolean, default: true},
        linkedService: { type: mongoose.Schema.Types.ObjectId, ref: 'ActiveService' },
        created: {type: Date, default: Date.now},
    }
)
recurringInvoiceSchema.plugin(mongoosePaginate);
recurringInvoiceSchema.plugin(toJSON);
const RecurringInvoice = mongoose.model("RecurringInvoice", recurringInvoiceSchema);
module.exports = RecurringInvoice;
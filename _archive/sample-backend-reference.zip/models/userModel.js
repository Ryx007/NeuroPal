const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const userModel = mongoose.Schema(
    {
        name: {type: String, trim: true, required: true},
        phone: {type: Number, trim: true, required: true, unique: true},
        password: {type: String, required: true},
        type: {type: String, enum: ["admin", "agent", "accountant"], required: true},
        status: {type: Boolean, default: true},
        created: {type: Number, default: Date.now}
    }
)
userModel.plugin(toJSON);
const User = mongoose.model("User", userModel);
module.exports = User;
const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');

const paymentSchema = new mongoose.Schema({
    customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
    invoice: { type: mongoose.Schema.Types.ObjectId, ref: 'Invoice',  required: true },
    payType: { type: String, required: true},
    amount: { type: Number, required: true},
    note: {type: String},
    payDate: {type: Date, default: Date.now}
});
paymentSchema.plugin(toJSON);
paymentSchema.plugin(mongoosePaginate);
const Payment = mongoose.model('Payment', paymentSchema);

module.exports = Payment;
const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const StateSchema = new mongoose.Schema({
    name: { type: String, required: true },
    code: { type: Number, required: true}
});
StateSchema.plugin(toJSON);

const State = mongoose.model('State', StateSchema);
module.exports = State;

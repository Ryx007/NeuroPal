const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const FinancialYearSchema = new mongoose.Schema({
    name: { type: String, required: true}
});
FinancialYearSchema.plugin(toJSON);
const FinancialYear = mongoose.model('FinancialYear', FinancialYearSchema);

module.exports = FinancialYear;
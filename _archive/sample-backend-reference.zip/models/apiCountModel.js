const mongoose = require('mongoose');

const dateCountSchema = new mongoose.Schema({
    date: { type: Date, required: true },
    type: { type: String, enum: ['email'], required: true, default: 'email' },
    count: { type: Number, required: true, default: 0 }
});

// Ensure the combination of date and type is unique
dateCountSchema.index({ date: 1, type: 1 }, { unique: true });

const ApiCount = mongoose.model('ApiCount', dateCountSchema);
module.exports = ApiCount;

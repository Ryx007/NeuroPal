const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const complianceConfigSchema = new mongoose.Schema({
    name: { type: String, required: true},
    expiry: { type: Date},
    new: { type: Boolean, default: false},
    days: { type: Number},
    financialYear: { type: mongoose.Schema.Types.ObjectId, ref: 'FinancialYear', required: true},
    expiryTemplate: { type: mongoose.Schema.Types.ObjectId, ref: 'EmailTemplate', default: null},
    completeTemplate: { type: mongoose.Schema.Types.ObjectId, ref: 'EmailTemplate', default: null}
});
complianceConfigSchema.plugin(toJSON);
const ComplianceConfig = mongoose.model('ComplianceConfig', complianceConfigSchema);

module.exports = ComplianceConfig;
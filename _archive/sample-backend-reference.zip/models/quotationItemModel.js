const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const quotationItemModel = mongoose.Schema(
    {
        lead: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead' },
        customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
        quotation: { type: mongoose.Schema.Types.ObjectId, ref: 'Quotation' },
        itemName: {type: String, required: true},
        product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
        professional: {type: Number, default: 0},
        govt: {type: Number, default: 0},
        price: {type: Number, default: 0},
        cgst: {type: Number, default: 0},
        cgstAmt: {type: Number, default: 0},
        igst: {type: Number, default: 0},
        igstAmt: {type: Number, default: 0},
        sgst: {type: Number, default: 0},
        sgstAmt: {type: Number, default: 0},
        gst: {type: Number, default: 0},
        total: {type: Number, default: 0},
        created: {type: Number, default: Date.now}
    }
)
quotationItemModel.plugin(toJSON);
const QuotationItem = mongoose.model("QuotationItem", quotationItemModel);
module.exports = QuotationItem;
const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const configSchema = new mongoose.Schema({
    name: {type: String},
    value: {type: mongoose.Schema.Types.Mixed}
});
configSchema.plugin(toJSON);
const Config = mongoose.model('Config', configSchema);

module.exports = Config;
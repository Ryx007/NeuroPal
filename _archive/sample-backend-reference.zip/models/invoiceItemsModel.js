const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const invoiceItemsSchema = mongoose.Schema(
    {
        customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
        invoice: { type: mongoose.Schema.Types.ObjectId, ref: 'Invoice', required: true },
        itemName: {type: String, required: true},
        product: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
        professional: {type: Number, default: 0},
        govt: {type: Number, default: 0},
        price: {type: Number, default: 0},
        cgst: {type: Number, default: 0},
        cgstAmt: {type: Number, default: 0},
        igst: {type: Number, default: 0},
        igstAmt: {type: Number, default: 0},
        sgst: {type: Number, default: 0},
        sgstAmt: {type: Number, default: 0},
        gst: {type: Number, default: 0},
        total: {type: Number, default: 0},
        created: {type: Number, default: Date.now}
    }
)
invoiceItemsSchema.plugin(toJSON);
const InvoiceItem = mongoose.model("InvoiceItem", invoiceItemsSchema);
module.exports = InvoiceItem;
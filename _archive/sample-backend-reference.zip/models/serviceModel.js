const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const serviceModel = mongoose.Schema(
    {
        name: {type: String, trim: true, required: true},
        status: {type: Boolean, default: true},
        template: {type: mongoose.Schema.Types.ObjectId, ref: 'EmailTemplate', required: true},
        professional: {type: Number, default: 0, required: true},
        govt: {type: Number, default: 0, required: true},
        hsn: {type: String, default: ''},
        created: {type: Number, default: Date.now}
    }
)
serviceModel.plugin(toJSON);
const Service = mongoose.model("Service", serviceModel);
module.exports = Service;
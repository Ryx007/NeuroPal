const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');
const invoiceSchema = mongoose.Schema(
    {
        customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
        invoiceNo: {type: String, required: true},
        price: {type: Number, default: 0},
        cgst: {type: Number, default: 0},
        igst: {type: Number, default: 0},
        sgst: {type: Number, default: 0},
        gst: {type: Number, default: 0},
        total: {type: Number, default: 0},
        due: {type: Number, default: 0},
        invDate: {type: Date, required: true},
        recurring: { type: mongoose.Schema.Types.ObjectId, ref: 'RecurringInvoice' },
        linkedService: { type: mongoose.Schema.Types.ObjectId, ref: 'ActiveService' },
        desc: {type: String, default: ''}
    }
)
invoiceSchema.plugin(mongoosePaginate);
invoiceSchema.plugin(toJSON);
const Invoice = mongoose.model("Invoice", invoiceSchema);
module.exports = Invoice;
const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const LeadNotesSchema = new mongoose.Schema({
    lead: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead' },
    agent: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    note: { type: String },
    call: { type: Boolean, default: false},
    template: { type: mongoose.Schema.Types.ObjectId, ref: 'EmailTemplate' },
    templateSubject: { type: String },
    created: { type: Number, default: Date.now}
});

LeadNotesSchema.plugin(toJSON);
const LeadNote = mongoose.model('LeadNote', LeadNotesSchema);
module.exports = LeadNote;

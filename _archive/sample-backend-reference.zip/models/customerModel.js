const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');
const customerModel = mongoose.Schema(
    {
        name: {type: String, trim: true, required: true},
        phone: {type: Number, required: true},
        companyName: {type: String, trim: true, unique: true},
        emails: [
            {type: String}
        ],
        address: {type: String},
        state: { type: mongoose.Schema.Types.ObjectId, ref: 'State' },
        incorporationDate: {type: Date, required: true},
        activeServices: [{ _id: false, type: mongoose.Schema.Types.ObjectId, ref: 'Service' }],
        gst: {type: String},
        type: {type: String, enum: ["Private Limited Company","Proprietorship","Partnership","Public Limited Company","Section 8", "FPC","LLP","Trust","Others"]},
        onboardingDate: {type: Date, required: true},
        newlyIncorporated: {type: Boolean, default: false},
        directors: [
            {
                name: {type: String},
                phone: {type: Number}
            }
        ],
        saleBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
        compliance: {type: Boolean, default: false},
        financialYear: [
            { type: mongoose.Schema.Types.ObjectId, ref: 'FinancialYear'}
        ],
        password: {type: String},
        username: {type: String, unique: true}
    }
)
customerModel.plugin(mongoosePaginate);
customerModel.plugin(toJSON);
const Customer = mongoose.model("Customer", customerModel);
module.exports = Customer;
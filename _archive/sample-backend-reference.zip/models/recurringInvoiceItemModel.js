const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const recurringInvoiceItemSchema = mongoose.Schema(
    {
        customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
        invoice: { type: mongoose.Schema.Types.ObjectId, ref: 'RecurringInvoice', required: true },
        product: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
        professional: {type: Number, default: 0},
        govt: {type: Number, default: 0},
        gst: {type: Number, default: 0},
        created: {type: Number, default: Date.now}
    }
)
recurringInvoiceItemSchema.plugin(toJSON);
const RecurringInvoiceItem = mongoose.model("RecurringInvoiceItem", recurringInvoiceItemSchema);
module.exports = RecurringInvoiceItem;
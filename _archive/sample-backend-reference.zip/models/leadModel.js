const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');
const leadModel = mongoose.Schema(
    {
        name: {type: String, trim: true, required: true},
        phone: {type: Number, required: true},
        companyName: {type: String, trim: true},
        emails: [
            {type: String}
        ],
        service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service' },
        source: {type: String},
        assigned: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        lastCalled: {type: Number},
        doCall: {type: Boolean},
        lastFollowup: {type: Number},
        nextFollowup: {type: Number},
        type: {type: String, enum: ["hot", "cold"]},
        priority: {type: String, enum: ["low", "medium", "high"]},
        response: {type: String, enum: ["interested", "medium", "not interested"]},
        converted: {type: Boolean, default: false},
        address: {type: String},
        state: { type: mongoose.Schema.Types.ObjectId, ref: 'State' },
        interacted: {type: Boolean, default: false},
        created: {type: Number, default: Date.now},
        modified: {type: Number, default: Date.now}
    }
)
leadModel.plugin(mongoosePaginate);
leadModel.plugin(toJSON);
const Lead = mongoose.model("Lead", leadModel);
module.exports = Lead;
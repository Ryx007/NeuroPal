const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');

const SessionSchema = new mongoose.Schema({
    type: {type: String, enum: ['agent', 'accountant', 'admin', 'customer']},
    user: {type: mongoose.Schema.Types.ObjectId, required: true},
    device: { type: String, required: true },
    created: {type: Number, default: Date.now}
});

SessionSchema.plugin(toJSON);
const Session = mongoose.model('Session', SessionSchema);
module.exports = Session;

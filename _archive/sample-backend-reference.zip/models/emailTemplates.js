const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');

const EmailTemplateSchema = new mongoose.Schema({
    name: { type: String, required: true },
    content: {type: String, required: true},
    subject: {type: String, required: true},
    status: {type: Boolean, default: true},
    created: {type: Number, default: Date.now},
    attachments: [
        {
            filename: {type: String},
            path: {type: String}
        }
    ]
});
EmailTemplateSchema.plugin(toJSON);
EmailTemplateSchema.plugin(mongoosePaginate);

const EmailTemplate = mongoose.model('EmailTemplate', EmailTemplateSchema);
module.exports = EmailTemplate;

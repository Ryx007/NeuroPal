const mongoose = require('mongoose');
const toJSON = require('@meanie/mongoose-to-json');
const mongoosePaginate = require('mongoose-paginate-v2');

const complianceSchema = new mongoose.Schema({
    customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
    financialYear: { type: mongoose.Schema.Types.ObjectId, ref: 'FinancialYear', required: true},
    compliance: { type: mongoose.Schema.Types.ObjectId, ref: 'ComplianceConfig', required: true},
    status: { type: String, enum: ["Done", "Ongoing", "To Be Done"], default: "To Be Done", required: true},
    doneOn: { type: Date},
    accountant: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});
complianceSchema.plugin(toJSON);
complianceSchema.plugin(mongoosePaginate);
const Compliance = mongoose.model('Compliance', complianceSchema);

module.exports = Compliance;
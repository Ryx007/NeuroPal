sudo apt-get install chromium-browser
which chromium-browser
const browser: puppeteer.Browser = await puppeteer.launch({
  executablePath: '/usr/bin/chromium-browser', <-------
  }); 
const express = require('express');
const { userVerify } = require('../libs/auth');
const Customer = require('../models/customerModel');
const AccountantJob = require('../models/accountantJobsModel');

const router = express.Router();

router.post('/jobs/:page', userVerify, async(req, res)=>{
    try{
        const page = parseInt(req.params.page) || 1;
        if(!page){
            throw new Error('Missing Page Number');
        }
        if (Number.isNaN(page) || !Number.isInteger(page) || page < 1) {
            throw new Error('Invalid Page Number');
        }

        const {name, status, accountant, start, end, dtype} = req.body;

        const options = {
            page: page,
            limit: 50,
            sort: { _id: -1 },
            populate: [{path: 'customer', select: 'name phone companyName'}, {path: 'accountant', select: 'name'}]
        };

        let query = {};
        if(name && name.trim() != ""){
            const regex = new RegExp(name, 'i');
            const matchingCustomers = await Customer.find({
                $or: [
                    { name: { $regex: regex } },
                    { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                    { companyName: { $regex: regex } }
                ]
            }).select('_id');

            const userIds = matchingCustomers.map(customer => customer._id);

            query.$or = [
                { customer:  { $in: userIds } },
                { jobTitle: regex }
            ];
        }
        if(start > 0 && end > 0 && end > start){
            const dateFieldMap = {
                "created": "created",
                "expiry": "expiryDate",
                "doneOn": "doneOn"
            };
            const dateField = dateFieldMap[dtype];
            if (dateField) {
                query[dateField] = { $gte: new Date(start), $lte: new Date(end) };
            }
        }
        if (status && Array.isArray(status) && status.length > 0) {
            query.status = { $in: status };
        }
        if (accountant && Array.isArray(accountant) && accountant.length > 0) {
            query.accountant = { $in: accountant };
        }

        const jobs = await AccountantJob.paginate(query, options);
        res.json({
            status: true,
            data: jobs
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.post('/new', userVerify, async(req, res)=>{
    try{
        const {title, customer, accountant, expiryDate, isExpiry, status} = req.body;
        if(!title || !accountant){
            throw new Error('Missing Data');
        }
        let obj = {
            jobTitle: title,
            accountant: accountant,
            status: status
        }
        if(customer){
            obj.customer = customer.id
        }
        if(isExpiry){
            let expiry = new Date(expiryDate);
            expiry.setHours(0, 0, 0, 0);
            obj.expiryDate = expiry;
        }
        if(status == "Done"){
            obj.doneOn = new Date();
        }

        const job = await AccountantJob.create(obj);
        const data = await AccountantJob.findById(job.id).populate({path: 'customer', select: 'name phone companyName'}).populate({path: 'accountant', select: 'name'});
        res.json({
            status: true,
            data: data
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/edit', userVerify, async(req, res)=>{
    try{
        const {id, title, customer, accountant, expiryDate, isExpiry, status} = req.body;
        if(!id || !title || !accountant){
            throw new Error('Missing Data');
        }
        let obj = {
            jobTitle: title,
            accountant: accountant,
            status: status
        }
        if(customer){
            obj.customer = customer.id
        }
        if(isExpiry){
            let expiry = new Date(expiryDate);
            expiry.setHours(0, 0, 0, 0);
            obj.expiryDate = expiry;
        }else{
            obj.expiryDate = null;
        }
        if(status == "Done"){
            obj.doneOn = new Date();
        }else{
            obj.doneOn = null;
        }
        const data = await AccountantJob.findByIdAndUpdate(id, obj, {new: true}).populate({path: 'customer', select: 'name phone companyName'}).populate({path: 'accountant', select: 'name'});

        res.json({
            status: true,
            data: data
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/delete/:jid', userVerify, async(req, res)=>{
    try{
        const jid = req.params.jid;
        await AccountantJob.deleteOne({_id: jid});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

module.exports = router;
const express = require('express');
const { userVerify } = require('../libs/auth');
const Lead = require('../models/leadModel');
const Customer = require('../models/customerModel');
const TemplateHistory = require('../models/templateHistory');
const Service = require('../models/serviceModel');
const ActiveService = require('../models/activeServiceModel');
const EmailTemplate = require('../models/emailTemplates');
const ComplianceConfig = require('../models/complianceConfigModel');
const Compliance = require('../models/complianceModel');
const { annualComplianceId, generateRandomPassword, doubletickFrom, doubletickApiKey } = require('../libs/common');
const RecurringInvoice = require('../models/recurringInvoiceModel');
const { getInvoice, generatePDF } = require('../libs/invoice');
const RecurringInvoiceItem = require('../models/recurringInvoiceItemModel');
const Invoice = require('../models/invoiceModel');
const moment = require('moment');
const { sendEmails } = require('../libs/email');
const AccountantJob = require('../models/accountantJobsModel');
const { default: axios } = require('axios');
const InvoiceItem = require('../models/invoiceItemsModel');
const { default: puppeteer } = require('puppeteer');
const PDFDocument = require('pdfkit');
const { format } = require('@fast-csv/format');
const router = express.Router();

router.post('/lists/:page', userVerify, async(req, res)=>{
    try{
        const page = parseInt(req.params.page) || 1;
        if(!page){
            throw new Error('Missing Page Number');
        }
        if (Number.isNaN(page) || !Number.isInteger(page) || page < 1) {
            throw new Error('Invalid Page Number');
        }

        const {name, service, type, start, end, dtype} = req.body;

        const options = {
            page: page,
            limit: 50,
            sort: { _id: -1 },
            populate: {path: 'activeServices', select: 'name'}
        };

        let query = {};
        if(name && name.trim() != ""){
            const regex = new RegExp(name, 'i');
            query.$or = [
                { name: regex },
                { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                { companyName: regex }
            ];
        }
        if(start > 0 && end > 0 && end > start){
            const dateFieldMap = {
                "incorporationDate": "incorporationDate",
                "onboardingDate": "onboardingDate"
            };
            const dateField = dateFieldMap[dtype];
            if (dateField) {
                query[dateField] = { $gte: new Date(start), $lte: new Date(end) };
            }
        }
        if (type && Array.isArray(type) && type.length > 0) {
            query.type = { $in: type };
        }
        if (service && Array.isArray(service) && service.length > 0) {
            query['activeServices'] = { $in: service };
        }

        const customers = await Customer.paginate(query, options);
        res.json({
            status: true,
            data: customers
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.get('/csv', userVerify, async(req, res)=>{
    try{
        const data = JSON.parse(req.query.data);
        const {name, service, type, start, end, dtype} = data;

        let query = {};
        if(name && name.trim() != ""){
            const regex = new RegExp(name, 'i');
            query.$or = [
                { name: regex },
                { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                { companyName: regex }
            ];
        }
        if(start > 0 && end > 0 && end > start){
            const dateFieldMap = {
                "incorporationDate": "incorporationDate",
                "onboardingDate": "onboardingDate"
            };
            const dateField = dateFieldMap[dtype];
            if (dateField) {
                query[dateField] = { $gte: new Date(start), $lte: new Date(end) };
            }
        }
        if (type && Array.isArray(type) && type.length > 0) {
            query.type = { $in: type };
        }
        if (service && Array.isArray(service) && service.length > 0) {
            query['activeServices'] = { $in: service };
        }

        const customers = await Customer.find(query).sort({ _id: -1 }).populate({ path: 'activeServices', select: 'name' });
        
        res.setHeader('Content-Disposition', 'attachment; filename="customers.csv"');
        res.setHeader('Content-Type', 'text/csv');
        const csvStream = format({ headers: true });
        csvStream.pipe(res); 

        for(const customer of customers){
            csvStream.write({name: customer.name, phone: customer.phone, companyName: customer.companyName, type: customer.type, incorporationDate: moment(customer.incorporationDate).format('DD/MM/YYYY'), onboardingDate: moment(customer.onboardingDate).format('DD/MM/YYYY'), gst: customer.gst, state: customer.state.name, saleBy: customer.saleBy.name, username: customer.username, password: customer.password, emails: customer.emails.join(', '), address: customer.address, activeServices: customer.activeServices.map(s => s.name).join(', ')});
        }

        csvStream.end();
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.get('/details/:id', userVerify, async(req, res)=>{
    try{
        const id = req.params.id;
        const customerData = await Customer.findById(id).populate({path: 'activeServices', select: 'name'}).populate({path: 'state', select: 'name'}).populate({path: 'saleBy', select: 'name'}).populate({path: 'financialYear', select: 'name'});

        if(!customerData){
            throw new Error('Invalid Customer ID');
        }

        res.json({
            status: true,
            data: customerData
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.get('/service/:id', userVerify, async(req, res)=>{
    try{
        const id = req.params.id;
        const serviceData = await ActiveService.find({customer: id}).populate({path: 'service', select: 'name professional govt'}).sort({ status: -1, start: -1 });

        res.json({
            status: true,
            data: serviceData
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.get('/emailhistory/:id', userVerify, async(req, res)=>{
    try{
        const id = req.params.id;
        const serviceData = await TemplateHistory.find({customer: id, type: "customer"}).populate({path: 'template', select: 'name'}).sort({ created: -1 });

        res.json({
            status: true,
            data: serviceData
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.post('/new', userVerify, async(req, res)=>{
    try{
        const {name, phone, company, address, gst, type, incorporation, state, newlyIncorporated, onboarding, saleBy, username} = req.body;
        if(!name || !phone || !company || !address || !type || !incorporation || !onboarding || !state || !saleBy || !username){
            throw new Error('Missing Data');
        }

        let incorporationDate = new Date(incorporation);
        incorporationDate.setHours(0, 0, 0, 0);

        let onboardingDate = new Date(onboarding);

        let obj = {
            name: name,
            phone: phone,
            companyName: company,
            address: address,
            type: type,
            gst: gst,
            incorporationDate: incorporationDate,
            onboardingDate: onboardingDate,
            state: state,
            newlyIncorporated: newlyIncorporated,
            saleBy: saleBy,
            password: generateRandomPassword(),
            username: username
        }


        const data = await Customer.create(obj);
        res.json({
            status: true,
            data: data
        })

    }catch(e){
        let msg = e.message;
        if(e.code === 11000){
            msg = "Company Name or Username already exists";
        }
        res.json({
            status: false,
            message: msg
        })
    }
})

router.post('/convert', userVerify, async(req, res)=>{
    try{
        const {id, company, address, gst, type, incorporation, state, newlyIncorporated, username} = req.body;
        if(!id || !company || !address || !type || !incorporation || !state || !username){
            throw new Error('Missing Data');
        }

        const leadData = await Lead.findById(id);
        if(!leadData){
            throw new Error('Invalid Lead ID');
        }
        if(!leadData.assigned){
            throw new Error('Assign a agent first');
        }

        let incorporationDate = new Date(incorporation);
        incorporationDate.setHours(0, 0, 0, 0);

        let today = new Date();
        today.setHours(0, 0, 0, 0);

        let obj = {
            name: leadData.name,
            phone: leadData.phone,
            emails: leadData.emails,
            companyName: company,
            address: address,
            type: type,
            gst: gst,
            incorporationDate: incorporationDate,
            onboardingDate: today,
            state: state,
            newlyIncorporated: newlyIncorporated,
            saleBy: leadData.assigned,
            password: generateRandomPassword(),
            username: username
        }

        const data = await Customer.create(obj);
        await Lead.findByIdAndUpdate(id, {converted: true});

        res.json({
            status: true,
            data: data.id
        })

    }catch(e){
        let msg = e.message;
        if(e.code === 11000){
            msg = "Company Name or Username already exists";
        }
        res.json({
            status: false,
            message: msg
        })
    }
})

router.post('/update', userVerify, async(req, res)=>{
    try{
        const {name, phone, company, address, gst, type, incorporation, state, newlyIncorporated, onboarding, username, id} = req.body;
        if(!name || !phone || !company || !address || !type || !incorporation || !onboarding || !state || !id || !username){
            throw new Error('Missing Data');
        }

        let incorporationDate = new Date(incorporation);
        incorporationDate.setHours(0, 0, 0, 0);

        let onboardingDate = new Date(onboarding);

        let obj = {
            name: name,
            phone: phone,
            companyName: company,
            address: address,
            type: type,
            gst: gst,
            incorporationDate: incorporationDate,
            onboardingDate: onboardingDate,
            state: state,
            newlyIncorporated: newlyIncorporated,
            username: username
        }


        const data = await Customer.findByIdAndUpdate(id, obj);
        res.json({
            status: true,
            data: data
        })

    }catch(e){
        let msg = e.message;
        if(e.code === 11000){
            msg = "Company Name or Username already exists";
        }
        if(e.name == "CastError"){
            msg = "Invalid Customer ID"
        }
        res.json({
            status: false,
            message: msg
        })
    }
})

router.post('/emails', userVerify, async(req, res)=>{
    try{
        const {id, emails} = req.body;
        await Customer.findByIdAndUpdate(id, {emails: emails});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.post('/director', userVerify, async(req, res) => {
    try{
        const {id, name, phone} = req.body;
        if(!id || !name || !phone){
            throw new Error('Missing Data');
        }

        await Customer.findByIdAndUpdate(
            id,
            { $push: { directors: {name, phone} } },
            { runValidators: true }
        );

        res.json({status: true});
    }catch(e){
        res.json({ 
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.post('/director/delete', userVerify, async(req, res) => {
    try{
        const {did, cid} = req.body;
        if(!did || !cid){
            throw new Error('Missing Data');
        }

        await Customer.findOneAndUpdate(
            { _id: cid },
            { $pull: { directors: { _id: did } } }
        );

        res.json({status: true});
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.post('/sendemail', userVerify, async(req, res)=>{
    try{
        let {id, content, subject, tid} = req.body;
        if(!id || !content || !subject || !tid){
            throw new Error('Missing Data');
        }
        const customerData = await Customer.findById(id);
        if(!customerData){
            throw new Error('Invalid Customer');
        }
        const emails = customerData.emails;
        if(!emails || emails.length == 0){
            throw new Error('No emails added to this customer');
        }

        subject = subject.replace(/{{name}}/g, customerData.name);
        subject = subject.replace(/{{companyName}}/g, customerData.companyName);
        subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

        content = content.replace(/{{name}}/g, customerData.name);
        content = content.replace(/{{companyName}}/g, customerData.companyName);
        content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

        await TemplateHistory.create({customer: id, type: "customer", content: content, subject: subject, template: tid});

        const templateData = await EmailTemplate.findById(tid).select('attachments');

        res.json({
            status: true
        })
        await sendEmails(emails, subject, content, templateData.attachments);
    }catch(e){
        res.json({ 
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.post('/service', userVerify, async(req, res)=>{
    try{
        const {id, service, start, professional, govt, gst, recurring, end, interval, intervalType} = req.body;
        if(!id || !service || !start || !professional || isNaN(govt) || isNaN(gst)){
            throw new Error('Missing Data');
        }
        const startDate = new Date(start);
        startDate.setHours(0, 0, 0, 0);
        const nextDate = new Date(startDate);

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const serviceData = await Service.findById(service);
        const customerData = await Customer.findById(id).populate('state');
        if(!serviceData){
            throw new Error('Invalid Service');
        }
        if(!customerData){
            throw new Error('Invalid Customer');
        }

        const chkHistory = await ActiveService.findOne({customer: id, service: service, status: true});
        if(chkHistory){
            throw new Error('Selected Service already active for this customer');
        }

        if(recurring){
            if(!end || !interval || !intervalType){
                throw new Error('Missing Data');
            }

            const endDate = new Date(end);
            endDate.setHours(0, 0, 0, 0);

            if (intervalType === "day") {
                nextDate.setDate(nextDate.getDate() + parseInt(interval));
            } else if (intervalType === "month") {
                nextDate.setMonth(nextDate.getMonth() + parseInt(interval));
            }

            if (nextDate < today) {
                throw new Error("Start Date is too old for given interval.");
            }
            if (nextDate > endDate) {
                throw new Error("End Date is before next invoice date.");
            }
        }

        const activeService = await ActiveService.create({customer: id, service: service, start: startDate});
        await Customer.findByIdAndUpdate(id, {$push: {activeServices: service}});

        if(service == annualComplianceId){
            await Customer.findByIdAndUpdate(id, {compliance: true});
        }

        let invoiceData = null;
        if(!recurring){
            const result = await getInvoice(customerData.id, startDate, [{product: service, professional, govt, gst}], null, activeService.id);
            
            if(!result.status){
                throw new Error(result.message);
            }
            invoiceData = result.data;
        }else{
            const rInvData = await RecurringInvoice.create({customer: customerData.id, startDate: startDate, endDate: new Date(end), nextDate: nextDate, interval: interval, intervalType: intervalType, linkedService: activeService.id});

            let invItem = {
                customer: customerData.id,
                invoice: rInvData.id,
                product: service,
                professional: professional,
                govt: govt,
                gst: gst
            };
            await RecurringInvoiceItem.create(invItem);

            if(startDate <= today){
                const result = await getInvoice(customerData.id, startDate, [{product: service, professional, govt, gst}], rInvData.id, activeService.id);

                if(!result.status){
                    throw new Error(result.message);
                }
                invoiceData = result.data;
            }
        }

        res.json({
            status: true
        });
        //send service start email
        const template = await EmailTemplate.findById(serviceData.template);
        let subject = template.subject;
        let content = template.content;
        subject = subject.replace(/{{name}}/g, customerData.name);
        subject = subject.replace(/{{companyName}}/g, customerData.companyName);
        subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

        content = content.replace(/{{name}}/g, customerData.name);
        content = content.replace(/{{companyName}}/g, customerData.companyName);
        content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
        content = content.replace(/{{username}}/g, customerData.username);
        content = content.replace(/{{password}}/g, customerData.password);

        let invPdf = null;
        if(invoiceData){
            subject = subject.replace(/{{invoiceNo}}/g, invoiceData.invoiceNo);
            subject = subject.replace(/{{invoiceDate}}/g, moment(invoiceData.invDate).format('Do MMM YYYY'));
            subject = subject.replace(/{{invoiceAmount}}/g, "₹ "+parseFloat(invoiceData.total).toFixed(2));

            content = content.replace(/{{invoiceNo}}/g, invoiceData.invoiceNo);
            content = content.replace(/{{invoiceDate}}/g, moment(invoiceData.invDate).format('Do MMM YYYY'));
            content = content.replace(/{{invoiceAmount}}/g, "₹ "+parseFloat(invoiceData.total).toFixed(2));
            const invoiceItems = await InvoiceItem.find({invoice: invoiceData.id}).populate({path: 'product', select: 'hsn'});
            const pdfBuffer = await generatePDF(customerData, invoiceData, invoiceItems);
            invPdf = {
                filename: invoiceData.invoiceNo+'.pdf',
                content: pdfBuffer, 
                contentType: 'application/pdf'
            }
        }

        await sendEmails(customerData.emails, subject, content, template.attachments, invPdf);
        await TemplateHistory.create({customer: customerData.id, type: "customer", content: content, subject: subject, template: template.id});
    }catch(e){
        res.json({ 
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.get('/endservice/:id', userVerify, async(req, res)=>{
    try{
        const id = req.params.id;
        const serviceData = await ActiveService.findById(id);
        if(!serviceData){
            throw new Error('Invalid Service ID');
        }
        if(!serviceData.status){
            throw new Error('Service already ended');
        }
        await ActiveService.findByIdAndUpdate(id, {end: new Date(), status: false});
        await Customer.findByIdAndUpdate(serviceData.customer, {$pull: {activeServices: serviceData.service}});

        if(serviceData.service == annualComplianceId){
            await Customer.findByIdAndUpdate(serviceData.customer, {compliance: false});
        }
        await RecurringInvoice.updateMany({customer: serviceData.customer, linkedService: serviceData.id, status: true}, {status: false});

        res.json({
            status: true
        })
    }catch(e){
        res.json({ 
            status: false,
            message: e.name == "CastError"?'Invalid Service ID':e.message
        })
    }
});

router.post('/invoice', userVerify, async(req, res)=>{
    try{
        const {id, service, start, professional, govt, gst, recurring, end, interval, intervalType, linkedService} = req.body;
        if(!id || !service || !start || !professional || isNaN(govt) || isNaN(gst)){
            throw new Error('Missing Data');
        }
        const startDate = new Date(start);
        startDate.setHours(0, 0, 0, 0);
        const nextDate = new Date(startDate);

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const serviceData = await Service.findById(service);
        const customerData = await Customer.findById(id);
        if(!serviceData){
            throw new Error('Invalid Service');
        }
        if(!customerData){
            throw new Error('Invalid Customer');
        }

        if(recurring){
            if(!end || !interval || !intervalType){
                throw new Error('Missing Data');
            }

            const endDate = new Date(end);
            endDate.setHours(0, 0, 0, 0);

            if (intervalType === "day") {
                nextDate.setDate(nextDate.getDate() + parseInt(interval));
            } else if (intervalType === "month") {
                nextDate.setMonth(nextDate.getMonth() + parseInt(interval));
            }

            if (nextDate < today) {
                throw new Error("Start Date is too old for given interval.");
            }
            if (nextDate > endDate) {
                throw new Error("End Date is before next invoice date.");
            }
        }

        if(!recurring){
            const result = await getInvoice(customerData.id, startDate, [{product: service, professional, govt, gst}], null, linkedService);
            
            if(!result.status){
                throw new Error(result.message);
            }
        }else{
            const rInvData = await RecurringInvoice.create({customer: customerData.id, startDate: startDate, endDate: new Date(end), nextDate: nextDate, interval: interval, intervalType: intervalType, linkedService: linkedService});

            let invItem = {
                customer: customerData.id,
                invoice: rInvData.id,
                product: service,
                professional: professional,
                govt: govt,
                gst: gst
            };
            await RecurringInvoiceItem.create(invItem);

            if(startDate <= today){
                const result = await getInvoice(customerData.id, startDate, [{product: service, professional, govt, gst}], rInvData.id, linkedService);

                if(!result.status){
                    throw new Error(result.message);
                }
            }
        }

        res.json({
            status: true
        });
    }catch(e){
        res.json({ 
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})


router.post('/addfy', userVerify, async(req, res)=>{
    try{
        const {id, fy, inc20} = req.body;
        if(!id || !fy){
            throw new Error('Missing Data');
        }
        const customerData = await Customer.findById(id);
        if(!customerData){
            throw new Error('Invalid Customer');
        }
        if (customerData.financialYear.includes(fy)) {
            throw new Error('Financial Year already added');
        }

        const complianceData = await ComplianceConfig.find({financialYear: fy});
        if(complianceData.length == 0){
            throw new Error('No Compliance for given Financial Year');
        }
        const complianceToAdd = complianceData.filter(c => !c.new);

        if (inc20) {
            complianceToAdd.push(...complianceData.filter(c => c.new));
        }

        complianceToAdd.sort((a, b) => new Date(a.expiry) - new Date(b.expiry));

        const complianceDocs = complianceToAdd.map(compliance => ({
            customer: id,
            financialYear: fy,
            compliance: compliance._id
        }));

        await Compliance.insertMany(complianceDocs);

        await Customer.findByIdAndUpdate(id, { $push: { financialYear: fy } });

        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.post('/compliances', userVerify, async(req, res)=>{
    try{
        const {id, fy} = req.body;
        if(!id || !fy){
            throw new Error('Missing Data');
        }
        const customerData = await Customer.findById(id);
        if(!customerData){
            throw new Error('Invalid Customer');
        }

        const complianceData = await Compliance.find({customer: id, financialYear: fy}).select('status doneOn').populate({path: 'compliance', select: 'name expiry days'}).populate({path: 'accountant', select: 'name'});

        res.json({
            status: true,
            data: complianceData
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
});

router.post('/compliance/update', userVerify, async(req, res)=>{
    try{
        const {id, status, accountant} = req.body;
        if(!id || !status || !accountant){
            throw new Error('Missing Data');
        }
        let obj = {
            status: status
        }
        if(accountant != "None"){
            obj.accountant = accountant;
        }
        if(status == "Done"){
            obj.doneOn = new Date();
        }else{
            obj.doneOn = null;
        }

        const data = await Compliance.findByIdAndUpdate(id, obj, {new: true}).populate({path: 'customer', select: 'name companyName address emails'});
        const complianceData = await ComplianceConfig.findById(data.compliance).select('name expiry days').populate({path: 'completeTemplate', select: 'subject content attachments'});

        //check accountant job
        if(data.accountant){
            const accountantJob = await AccountantJob.findOne({compliance: data.id});
            if(!accountantJob){
            	let cExpiry = complianceData.expiry;
                if(complianceData.days){
                    cExpiry = new Date(data.customer.incorporationDate);
                    cExpiry.setDate(cExpiry.getDate() + complianceData.days);
                }
                await AccountantJob.create({customer: data.customer.id, accountant: data.accountant, compliance: data.id, status: status, doneOn: data.doneOn?data.doneOn:null, expiryDate: cExpiry, jobTitle: complianceData.name});
            }else{
                await AccountantJob.findByIdAndUpdate(accountantJob.id, {accountant: data.accountant, status: status, doneOn: data.doneOn?data.doneOn:null});
            }
        }

        if(status == "Done" && complianceData.completeTemplate){
            const customerData = data.customer;
            let subject = complianceData.completeTemplate.subject;
            let content = complianceData.completeTemplate.content;

            subject = subject.replace(/{{name}}/g, customerData.name);
            subject = subject.replace(/{{companyName}}/g, customerData.companyName);
            subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
            subject = subject.replace(/{{complianceName}}/g, complianceData.name);
            subject = subject.replace(/{{complianceDoneDate}}/g, moment(obj.doneOn).format('Do MMM YYYY'));
            if(complianceData.expiry){
                subject = subject.replace(/{{complianceExpiryDate}}/g, moment(complianceData.expiry).format('Do MMM YYYY'));
            }
    
            content = content.replace(/{{name}}/g, customerData.name);
            content = content.replace(/{{companyName}}/g, customerData.companyName);
            content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
            content = content.replace(/{{complianceName}}/g, complianceData.name);
            content = content.replace(/{{complianceDoneDate}}/g, moment(obj.doneOn).format('Do MMM YYYY'));
            if(complianceData.expiry){
                content = content.replace(/{{complianceExpiryDate}}/g, moment(complianceData.expiry).format('Do MMM YYYY'));
            }

            await TemplateHistory.create({customer: customerData.id, type: "customer", content: content, subject: subject, template: complianceData.completeTemplate.id});

            sendEmails(customerData.emails, subject, content, complianceData.completeTemplate.attachments);
        }

        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Compliance ID':e.message
        })
    }
});

router.get('/invoices/:cid', userVerify, async(req, res)=>{
    try{
        const cid = req.params.cid;
        const invoices = await Invoice.find({customer: cid}).sort({invDate: -1}).sort({invDate: -1, _id: -1}).populate({path: 'linkedService', select: '_id', populate: {path: 'service', select: 'name'}});
        const recurringInvoices = await RecurringInvoice.find({customer: cid}).populate({path: 'linkedService', select: '_id', populate: {path: 'service', select: 'name'}});

        res.json({
            status: true,
            invoice: invoices,
            recurring: recurringInvoices
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.post('/whatsapptemplate', userVerify, async(req, res)=>{
    try{
        const {id, obj} = req.body;
        if(!id || !obj){
            throw new Error('Missing Data');
        }
        const customerData = await Customer.findById(id).select('phone');
        if(!customerData){
            throw new Error('Invalid Customer');
        }
        let waObj = {
            messages: [
                {
                    content: obj,
                    from: doubletickFrom,
                    to: '+91'+customerData.phone
                }
            ]
        }

        const resp = await axios.post("https://public.doubletick.io/whatsapp/message/template", waObj, {headers: {Accept: "application/json", Authorization: doubletickApiKey}});

        res.json({
            status: true,
            data: resp.data
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/boardresolution/:cid', async(req, res)=>{
    try{
        const cid = req.params.cid;
        const {date1, date2} = req.query;
        const customerData = await Customer.findById(cid);
        if(!customerData){
            throw new Error('Invalid Customer');
        }
        if(customerData.directors.length == 0){
            throw new Error('No Directors added to this customer');
        }
        let dirName = "";
        if(customerData.directors.length == 2){
            dirName = customerData.directors[0].name.toUpperCase()+" and "+customerData.directors[1].name.toUpperCase();
        }else{
            dirName = customerData.directors[0].name.toUpperCase();
        }
        const browser = await puppeteer.launch({
            executablePath: '/usr/bin/chromium-browser',
            headless: true,
            args: [
                  '--no-sandbox',
                  '--disable-setuid-sandbox',
                  '--disable-dev-shm-usage',
                  '--disable-accelerated-2d-canvas',
                 '--disable-gpu',
            ],
        });
        const page = await browser.newPage();

        let htmlContent = `
        <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Board Resolution - Auditor Appointment</title>
                <style>
                    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

                    body {
                        font-family: 'Poppins', sans-serif;
                        margin: 20px;
                        line-height: 1.6;
                        font-size: 16px;
                        font-weight: 500;
                        padding-left: 20px;
                        padding-right: 20px;
                    }
                    .header {
                        text-align: center;
                        margin-bottom: 20px;
                    }
                    .content {
                        text-align: justify;
                    }
                    .signature {
                        margin-top: 30px;
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    `+customerData.companyName.toUpperCase()+`<br>
                    `+customerData.address.toUpperCase()+`
                </div>
                <div class="content">
                    <p>CERTIFIED TRUE COPY OF THE RESOLUTION PASSED AT THE MEETING OF THE BOARD OF DIRECTORS OF `+customerData.companyName.toUpperCase()+` HELD AT `+customerData.address.toUpperCase()+`. </p>
                    <p>Board Resolution for appointment of first auditor of `+customerData.companyName.toUpperCase()+`. </p>
                    <p>Date: `+date1+` </p>
                    <p>
                        At the meeting of the Board of Directors of `+customerData.companyName.toUpperCase()+`, held on 
                        `+date2+`, it was:
                    </p>
                    <p>
                        RESOLVED THAT  Pursuant to the provisions of section 139 and 142 of the companies  Act, 2013 read with Rule 3 of the companies (Audit and Auditors) Rules, 2014 and other applicable provisions of the companies Act, 2013 read with rules made thereunder (including any statutory modification(s) or re-enactment there of for the time being in force) , consent of the Board be and is hereby accorded to appoint Mr. Jagjyot Singh, Firm M/s. JAGJYOT SINGH AND ASSOCIATES (Firm Registration No- 333567E) as First Auditors of the company to hold office till the conclusion of the First Annual General Meeting of the company, to examine and audit the accounts of the company , on such remuneration as may be mutually agreed upon between `+dirName+`, Directors of the company and the Auditors. 
                    </p>
                    <p>
                        RESOLVED FURTHER THAT `+dirName+` - Directors of the company be and is hereby authorized to do all such acts, deeds and things and execute such other documents as may be necessary for the purpose of giving effect to this resolution.   
                    </p>
                </div>
                <div class="signature" style="display: flex; justify-content: space-between;">
                    <div style="flex: 1">
                        <p>
                            `+customerData.directors[0].name.toUpperCase()+`<br><br><br><br>
                            Director
                        </p>
                    </div>`;

    if(customerData.directors[1]){
        htmlContent += `
                    <div style="flex: 1; text-align: right">
                        <p>
                            `+customerData.directors[1].name.toUpperCase()+`<br><br><br><br>
                            Director
                        </p>
                    </div>`;
    }

    htmlContent += `
                </div>
            </body>
        </html>
        `;
        await page.setContent(htmlContent);
        const pdfBuffer = await page.pdf({
            format: 'A4',
            printBackground: true,
            margin: { top: '40px', right: '40px', bottom: '40px', left: '40px' },
        });
        await browser.close();
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'inline; filename="board_resoltuion.pdf"');
        res.end(pdfBuffer);
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.get('/independent-auditor-report/:cid', async (req, res) => {
    try{
        const cid = req.params.cid;
        const customerData = await Customer.findById(cid).select('companyName');
        if(!customerData){
            throw new Error('Invalid Customer');
        }
        const {cin, date, udin} = req.query;
        if(!cin || !date || !udin){
            throw new Error('CIN and Date and UDIN are required');
        }

        const companyName = customerData.companyName;

        const filename = `Auditor-Report-${companyName.replace(/[^a-z0-9]/gi, '_')}.pdf`;
        res.setHeader('Content-disposition', `inline; filename="${filename}"`);
        res.setHeader('Content-type', 'application/pdf');

        // Build and stream the PDF
        buildAuditorReportPDF(res, companyName, cin, date, udin);
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        });
    }
});
router.get('/director-report/:cid', async (req, res) => {
    try{
        const cid = req.params.cid;
        const customerData = await Customer.findById(cid).select('companyName');
        if(!customerData){
            throw new Error('Invalid Customer');
        }
        const {place, date, profitTable, agmDate, directors, cin, noOfBoardMeetings, signingDirectors} = req.query;
        if(!place || !date || !profitTable || !agmDate || !directors || !cin || !noOfBoardMeetings || !signingDirectors){
            throw new Error('Place and Date and Profit Table and AGM Date and Directors and CIN and No Of Board Meetings and Signing Directors are required');
        }

        const companyName = customerData.companyName;

        const filename = `Director-Report-${companyName.replace(/[^a-z0-9]/gi, '_')}.pdf`;
        res.setHeader('Content-disposition', `inline; filename="${filename}"`);
        res.setHeader('Content-type', 'application/pdf');

        // Build and stream the PDF
        buildDirectorReportPDF(res, companyName, place, date, cin, noOfBoardMeetings, JSON.parse(profitTable), agmDate, JSON.parse(directors), JSON.parse(signingDirectors));
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        });
    }
});
router.get('/consent-letter/:cid', async (req, res) => {
    try{
        const cid = req.params.cid;
        const customerData = await Customer.findById(cid).select('companyName incorporationDate address');
        if(!customerData){
            throw new Error('Invalid Customer');
        }
        const {date} = req.query;
        if(!date){
            throw new Error('Date is required');
        }

        const companyName = customerData.companyName;
        const companyAddress = customerData.address;
        const incorporationDate = customerData.incorporationDate ? moment(customerData.incorporationDate).format('Do MMMM, YYYY') : "N/A";

        const filename = `Consent-Letter-${companyName.replace(/[^a-z0-9]/gi, '_')}.pdf`;
        res.setHeader('Content-disposition', `inline; filename="${filename}"`);
        res.setHeader('Content-type', 'application/pdf');

        // Build and stream the PDF
        buildConsentLetterPDF(res, companyName, companyAddress, incorporationDate, date);
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        });
    }
});
function buildAuditorReportPDF(res, companyName, cin, date, udin) {
    const spaceFromEdge = 72; 
    // Calculate the reporting date: 31st March of this year if today > 31st March, else 31st March of last year
    const now = new Date();
    const currentYear = now.getFullYear();
    const march31ThisYear = new Date(currentYear, 2, 31); // Month is 0-based, so 2 = March
    let reportYear;
    if (now > march31ThisYear) {
        reportYear = currentYear;
    } else {
        reportYear = currentYear - 1;
    }
    const dateString = `31st March ${reportYear}`;

    const doc = new PDFDocument({
        size: 'A4',
        margins: { top: 80, bottom: 80, left: spaceFromEdge, right: spaceFromEdge },
        bufferPages: true, // Crucial for the new header/footer logic
        // permissions: {
        //     printing: 'highResolution', // Allowed printing
        //     modifying: false,
        //     copying: false,
        //     annotating: false,
        //     fillingForms: false,
        //     contentAccessibility: false,
        //     documentAssembly: false
        // },
        // You must provide a password for permissions to be enforced.
        // This password does NOT prevent viewing, only changing permissions.
        // ownerPassword: 'amit_jagjyot'
    });

    doc.pipe(res);

    doc.fontSize(11).font('Poppins-Bold.ttf').text("INDEPENDENT AUDITOR’S REPORT");
    doc.fontSize(11).font('Poppins-Bold.ttf').text("To the Members of");
    doc.fontSize(11).font('Poppins-Bold.ttf').text(companyName);
    doc.fontSize(11).font('Poppins-Bold.ttf').text(`CIN: ${cin}`);
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);

    doc.fontSize(11).font('Poppins-Bold.ttf').text("Report on the Audit of the Financial Statements");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Opinion");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`We have audited the accompanying financial statements of `, {continued: true, align: 'justify'}).font('Poppins-Bold.ttf').text(`${companyName} `, {continued: true, align: 'justify'}).font('Poppins.ttf').text(`(“the Company”), which comprise the Balance Sheet as at ${dateString}, the Statement of Profit and Loss, the Statement of Changes in Equity, and the Cash Flow Statement for the year then ended, and a summary of the significant accounting policies and other explanatory information (collectively referred to as "the financial statements").`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`In our opinion and to the best of our information and according to the explanations given to us, the aforesaid financial statements give the information required by the Companies Act, 2013 (“the Act”) in the manner so required and give a true and fair view in conformity with the accounting principles generally accepted in India, of the state of affairs of the Company as at ${dateString}, its profit, changes in equity, and its cash flows for the year then ended.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Basis for Opinion");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`We conducted our audit in accordance with the Standards on Auditing (SAs) specified under Section 143(10) of the Act. We are independent of the Company in accordance with the Code of Ethics issued by the Institute of Chartered Accountants of India (ICAI), and we have fulfilled our other ethical responsibilities in accordance with these requirements and the ICAI’s Code of Ethics.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`We believe that the audit evidence we have obtained is sufficient and appropriate to provide a basis for our audit opinion.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Information Other than the Financial Statements and Auditor’s Report Thereon");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Company’s management and Board of Directors are responsible for the preparation of other information. The other information comprises the Board’s Report and its annexures, but does not include the financial statements and our auditor’s report thereon.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`Our opinion does not cover the other information and we do not express any form of assurance conclusion thereon. In connection with our audit of the financial statements, our responsibility is to read the other information and, in doing so, consider whether such information is materially inconsistent with the financial statements or our knowledge obtained in the audit. Based on the work performed, nothing has come to our attention that causes us to believe that there is a material misstatement of this other information.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Management’s Responsibility for the Financial Statements");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Company’s Board of Directors is responsible for the matters stated in Section 134(5) of the Act with respect to the preparation of these financial statements that give a true and fair view of the financial position, financial performance, changes in equity, and cash flows of the Company in accordance with the accounting principles generally accepted in India, including the Accounting Standards specified under Section 133 of the Act.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`This responsibility includes the maintenance of adequate accounting records in accordance with the provisions of the Act for safeguarding the assets of the Company and for preventing and detecting frauds and other irregularities; the selection and application of appropriate accounting policies; making judgments and estimates that are reasonable and prudent; and the design, implementation, and maintenance of adequate internal financial controls that were operating effectively for ensuring the accuracy and completeness of the accounting records relevant to the preparation and presentation of the financial statements.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`In preparing the financial statements, management is responsible for assessing the Company’s ability to continue as a going concern, disclosing, as applicable, matters related to going concern and using the going concern basis of accounting unless management either intends to liquidate the Company or to cease operations, or has no realistic alternative but to do so.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Board of Directors is also responsible for overseeing the Company’s financial reporting process.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Auditor’s Responsibilities for the Audit of the Financial Statements");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`Our objectives are to obtain reasonable assurance about whether the financial statements as a whole are free from material misstatement, whether due to fraud or error, and to issue an auditor’s report that includes our opinion. Reasonable assurance is a high level of assurance but is not a guarantee that an audit conducted in accordance with SAs will always detect a material misstatement when it exists.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text('As part of an audit in accordance with SAs, we:');
    doc.moveDown(0.5);
    doc.font('Poppins.ttf').fontSize(11).list([
        'Identify and assess the risks of material misstatement, whether due to fraud or error;',
        'Obtain an understanding of internal controls and assess their effectiveness;',
        'Evaluate the appropriateness of accounting policies used and the reasonableness of accounting estimates;',
        'Conclude on the appropriateness of the going concern assumption;',
        'Evaluate the overall presentation of the financial statements.',
    ], { bulletRadius: 2, paragraphGap: 5, indent: 20, align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`We communicate with those charged with governance regarding, among other matters, the planned scope and timing of the audit and significant audit findings, including any significant deficiencies in internal control that we identify during our audit.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Emphasis of Matter");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`We draw attention to the fact that no matters have been observed during the course of the audit that require emphasis. Hence, no Emphasis of Matter is reported.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Key Audit Matters");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`In our professional judgment, no Key Audit Matters need to be communicated in this report as per SA 701, “Communicating Key Audit Matters in the Independent Auditor’s Report”.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Reporting on Internal Financial Controls");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`We have audited the internal financial controls over financial reporting of the Company as of ${dateString} in conjunction with our audit of the financial statements.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`In our opinion, the Company has, in all material respects, an adequate internal financial control system over financial reporting and such internal financial controls were operating effectively as at ${dateString}, based on the internal control criteria established by the Company considering the essential components of internal control stated in the Guidance Note on Audit of Internal Financial Controls Over Financial Reporting issued by the ICAI.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Other Legal and Regulatory Requirements");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').list([
        'As required by the Companies (Auditor’s Report) Order, 2020 (“the Order”), issued by the Central Government of India in terms of Section 143(11) of the Act, we give in “Annexure A” a statement on the matters specified in paragraphs 3 and 4 of the Order, to the extent applicable.',
        'As required by Section 143(3) of the Act, we report that:',
    ], {  listType: 'numbered', paragraphGap: 5, indent: 0, align: 'justify' });
    doc.fontSize(11).font('Poppins.ttf').list([
        'We have obtained all the information and explanations which to the best of our knowledge and belief were necessary for the purposes of our audit;',
        'In our opinion, proper books of account as required by law have been kept by the Company so far as it appears from our examination of those books;',
        'The Balance Sheet, the Statement of Profit and Loss, the Statement of Changes in Equity, and the Cash Flow Statement dealt with by this report are in agreement with the books of account;',
        'In our opinion, the aforesaid financial statements comply with the Accounting Standards specified under Section 133 of the Act, read with Rule 7 of the Companies (Accounts) Rules, 2014;',
        `On the basis of written representations received from the directors as on ${dateString}, none of the directors is disqualified as on that date from being appointed as a director in terms of Section 164(2) of the Act.`
    ], spaceFromEdge+10, doc.y, { listType: 'lettered', paragraphGap: 5, indent: 30, align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("Other Matters as per Rule 11 of Companies (Audit and Auditors) Rules, 2014", spaceFromEdge, doc.y);
    doc.moveDown(0.5);
    doc.fontSize(10).font('Poppins.ttf').text(`Pursuant to Rule 11 of the Companies (Audit and Auditors) Rules, 2014, we report that:`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').list([
        'The Company does not have any pending litigations which would impact its financial position.',
        'The Company did not have any long-term contracts including derivative contracts for which there were any material foreseeable losses.',
        'There were no amounts that were required to be transferred to the Investor Education and Protection Fund during the year.',
        '.'
    ], {  listType: 'numbered', paragraphGap: 5, indent: 20, align: 'justify' });
    doc.fontSize(11).font('Poppins.ttf').list([
        'The Management has represented that, to the best of its knowledge and belief, no funds have been advanced or loaned or invested (either from borrowed funds, share premium or any other sources or kind of funds) by the Company to or in any other person(s) or entity(ies), including foreign entities (“Intermediaries”), with the understanding that the Intermediary shall:',
        [
            'directly or indirectly lend or invest in other persons or entities identified by or on behalf of the Company (Ultimate Beneficiaries); or',
            'provide any guarantee, security, or the like on behalf of the Ultimate Beneficiaries.'
        ],
        'The Management has represented that, to the best of its knowledge and belief, no funds have been received by the Company from any person(s) or entity(ies), including foreign entities (“Funding Parties”), with the understanding that the Company shall:',
        [
            'directly or indirectly lend or invest in other persons or entities identified by or on behalf of the Funding Party (Ultimate Beneficiaries); or',
            'provide any guarantee, security, or the like on behalf of the Ultimate Beneficiaries.'
        ],
        'Based on the audit procedures performed, nothing has come to our notice that has caused us to believe that the representations under sub-clauses (a) and (b) contain any material misstatement.'
    ], spaceFromEdge+11, doc.y - 21, { listType: 'lettered', paragraphGap: 5, indent: 28, align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).stroke();
    doc.moveDown(1);

    // --- SIGNATURE SECTION (STATIC) ---
    doc.fontSize(11).font('Poppins.ttf').text('For JAGJYOT SINGH & ASSOCIATES', spaceFromEdge, doc.y, { align: 'left' });
    doc.fontSize(11).font('Poppins.ttf').text('Chartered Accountants');
    doc.fontSize(11).font('Poppins.ttf').text('Firm Registration No.: 333567E');
    doc.moveDown(0.5);
    doc.image('sign.png', spaceFromEdge, doc.y, { width: 120 });
    doc.moveDown(3.5);

    doc.fontSize(11).font('Poppins.ttf').text('JAGJYOT SINGH');
    doc.fontSize(11).font('Poppins.ttf').text('Proprietor');
    doc.fontSize(11).font('Poppins.ttf').text('Membership No.: 319799');
    doc.fontSize(11).font('Poppins.ttf').text('UDIN: ' + udin);
    doc.moveDown(0.5);

    doc.fontSize(11).font('Poppins.ttf').text('Place: Kolkata');
    doc.fontSize(11).font('Poppins.ttf').text('Date: '+date);

    // --- HEADER AND FOOTER LOGIC (using buffered pages) ---
    let pages = doc.bufferedPageRange();
    for (let i = 0; i < pages.count; i++) {
        doc.switchToPage(i);

        // --- Header ---
        doc.image('calogo.jpg', 10, 20, { width: 50 });
        doc.fontSize(15).font('Poppins.ttf');
        doc.text("JAGJYOT SINGH & ASSOCIATES.", doc.page.margins.left, 20, { align: 'left' });
        doc.text("Firm Registration No. - 333567E", doc.page.margins.left, 40, { align: 'left' });

        // --- Footer ---
        let oldBottomMargin = doc.page.margins.bottom;
        doc.page.margins.bottom = 0 //Dumb: Have to remove bottom margin in order to write into it
        doc.fontSize(12).font('Poppins.ttf').text("PLOT 51, BLOCK BB – 102, SHANTIPALLY, SARAT PARK,", 0, doc.page.height - 65, { align: 'center', width: doc.page.width });
        doc.fontSize(12).font('Poppins.ttf').text("KOLKATA – 700107", 0, doc.page.height - 45, { align: 'center', width: doc.page.width });
        doc.page.margins.bottom = oldBottomMargin;
    }

    // Finalize the PDF and end the stream
    doc.end();
}

function buildDirectorReportPDF(res, companyName, place, date, cin, noOfBoardMeetings, profitTable, agmDate, directors, signingDirectors) {

    const spaceFromEdge = 72; 
    // Calculate the reporting date: 31st March of this year if today > 31st March, else 31st March of last year
    const now = new Date();
    const currentYear = now.getFullYear();
    const march31ThisYear = new Date(currentYear, 2, 31); // Month is 0-based, so 2 = March
    let reportYear;
    if (now > march31ThisYear) {
        reportYear = currentYear;
    } else {
        reportYear = currentYear - 1;
    }
    const dateString = `31st March ${reportYear}`;

    const doc = new PDFDocument({
        size: 'A4',
        margins: { top: 80, bottom: 80, left: spaceFromEdge, right: spaceFromEdge },
        bufferPages: true, // Crucial for the new header/footer logic
        // permissions: {
        //     printing: 'highResolution', // Allowed printing
        //     modifying: false,
        //     copying: false,
        //     annotating: false,
        //     fillingForms: false,
        //     contentAccessibility: false,
        //     documentAssembly: false
        // },
        // You must provide a password for permissions to be enforced.
        // This password does NOT prevent viewing, only changing permissions.
        // ownerPassword: 'amit_jagjyot'
    });

    doc.pipe(res);

    doc.fontSize(11).font('Poppins-Bold.ttf').text("DIRECTORS' REPORT");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("TO,");
    doc.fontSize(11).font('Poppins-Bold.ttf').text("THE MEMBERS,");
    doc.fontSize(11).font('Poppins-Bold.ttf').text(companyName);
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`Your Directors have the pleasure in presenting their Annual Report on the business and operation of the company and the accounts for the financial year ended ${dateString}.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);

    doc.fontSize(11).font('Poppins-Bold.ttf').text("1. FINANCIAL SUMMARY OR HIGHLIGHTS/PERFORMANCE OF THE COMPANY:");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The financial results for the year ended ${dateString} and the corresponding figures for the last year are as under:`, { align: 'justify' });
    doc.moveDown(0.5);

    doc.font('Poppins-Bold.ttf');
    doc.table({
        defaultStyle: { border: 1, borderColor: "gray" },
        rowStyles: (i) => {
            if (i % 2 != 0) return { backgroundColor: "#f2f2f2" };
        },
        columnStyles: (i) => {
            if (i === 0) return { width: 300 };
        },
        data: [
            [ 'Particulars', profitTable.header1, profitTable.header2 ],
            [ 'Profit Before interest, Depreciation & Tax', profitTable.profit1, profitTable.profit2 ],
            [ 'Less: Depreciation & Amortization Expense', profitTable.depreciation1, profitTable.depreciation2 ],
            [ 'Profit before Tax', profitTable.profitTax1, profitTable.profitTax2 ],
            [ 'Provision for Tax', profitTable.provision1, profitTable.provision2 ],
            [ 'Deferred Tax', profitTable.deferred1, profitTable.deferred2 ],
            [ 'Profit after Tax', profitTable.profitAfterTax1, profitTable.profitAfterTax2 ],
            [ 'Balance carried to Balance Sheet', profitTable.balance1, profitTable.balance2 ],
        ]
    });

    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("2. RESERVE & SURPLUS:");
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Company has not transferred any amount to reserves during the year under review.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("3. BRIEF DESCRIPTION OF THE COMPANY'S WORKING DURING THE YEAR/STATE OF COMPANY'S AFFAIRS:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`Your directors have to inform you that the Company’s gross revenue has changed from Rs. ${profitTable.grossProfit2} in FY ${profitTable.header2} to Rs. ${profitTable.grossProfit1} in FY ${profitTable.header1}.  The profit after tax has changed from Rs. ${profitTable.profitAfterTax2} in FY ${profitTable.header2} to Rs. ${profitTable.profitAfterTax1} in FY ${profitTable.header1}.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("4. CHANGE IN THE NATURE OF BUSINESS:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`There is no change in the nature of the business of the Company during the year under review.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("5. DIRECTORS' RESPONSIBILITY STATEMENT:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`Pursuant to the requirement under Section 134(5) of the Companies Act, 2013, the Board of Directors hereby confirms that: (a) In the preparation of the annual accounts, the applicable accounting standards had been followed along with proper explanation relating to material departures; (b) The directors had selected such accounting policies and applied them consistently and made judgments and estimates that are reasonable and prudent to give a true and fair view of the state of affairs of the Company at the end of the financial year and of the profit or loss of the Company for that period; (c) The directors had taken proper and sufficient care for the maintenance of adequate accounting records in accordance with the provisions of this Act for safeguarding the assets of the Company and for preventing and detecting fraud and other irregularities; (d) The directors had prepared the annual accounts on a going concern basis; and (e) The directors, in the case of a listed company, had laid down internal financial controls to be followed by the Company and that such internal financial controls are adequate and were operating effectively; (f) The directors had devised proper systems to ensure compliance with the provisions of all applicable laws and that such systems were adequate and operating effectively.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("6. DETAILS IN RESPECT OF FRAUDS REPORTED BY AUDITORS UNDER SUB-SECTION (12) OF SECTION 143:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`Pursuant to Section 143(12) of the Companies Act, 2013, the Auditors have not reported any frauds during the year that require disclosure.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("7. PARTICULARS OF LOANS, GUARANTEES OR INVESTMENTS UNDER SECTION 186:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(a) The Company has not given any loans, provided any guarantees, or made any investments in the securities of any other body corporate during the financial year. (b) No transactions have been undertaken which require reporting under Section 186 of the Companies Act, 2013.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("8. MATERIAL CHANGES AND COMMITMENTS AFFECTING THE FINANCIAL POSITION OF THE COMPANY:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`There have been no material changes and commitments affecting the financial position of the Company between the end of the financial year and the date of this report.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("9. DISCLOSURE OF RISK MANAGEMENT POLICY:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Company has formulated and implemented a Risk Management Policy to identify, assess, and mitigate risks. A Risk Management Committee oversees implementation and review.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("10. ANNUAL BOARD EVALUATION:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Board evaluation is not mandatory for private companies. However, the Board is committed to sound governance and informally assesses its own performance and that of individual directors.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("11. DISCLOSURES UNDER RULE 8/8A OF COMPANIES (ACCOUNTS) RULES, 2014:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(A) Opinion on Independent Directors: Not applicable as the provisions under Section 149(4) relating to Independent Directors do not apply to the Company.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(B) Internal Financial Controls: The Company has in place adequate internal financial controls with reference to the financial statements.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(C) Maintenance of Cost Records: Not applicable as the Company is not required to maintain cost records under Section 148(1).`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(D) Proceedings under IBC: No application has been made or is pending under the Insolvency and Bankruptcy Code, 2016.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(E) One-Time Settlement: No One-Time Settlement was undertaken with banks or financial institutions.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("12. CHANGES IN DIRECTORS AND KEY MANAGERIAL PERSONNEL:", { align: 'justify' });
    doc.moveDown(0.5);

    doc.font('Poppins.ttf').table({
        defaultStyle: { border: 1, borderColor: "gray" },
        rowStyles: (i) => {
            if (i % 2 != 0) return { backgroundColor: "#f2f2f2" };
        },
        data: [
            [ 'Name', 'Designation', 'Date of Appointment', 'Date of Resignation' ],
            ...directors.map(d => [d.name, d.designation, d.appointment, d.resignation || '-'])
        ]
    });

    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("13. DEPOSITS:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Company has neither accepted nor renewed any public deposits during the financial year under review.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("14. SIGNIFICANT AND MATERIAL ORDERS PASSED BY THE REGULATORS:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`No significant and material orders have been passed by regulators or courts or tribunals during the year which would impact the going concern status and future operations of the Company.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("15. DISCLOSURE UNDER THE SEXUAL HARASSMENT OF WOMEN AT WORKPLACE ACT:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Company has a policy for the prevention of sexual harassment of women at workplace and an Internal Complaints Committee is in place. No complaints were received during the year.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("16. MEETINGS OF THE BOARD:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`${noOfBoardMeetings} meetings of the Board of Directors were held during the financial year.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("17. CORPORATE SOCIAL RESPONSIBILITY (CSR):", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The provisions of CSR under Section 135 of the Companies Act, 2013 are not applicable to the Company.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("18. SUBSIDIARY, JOINT VENTURE AND ASSOCIATE COMPANIES:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Company has no Subsidiary, Joint Venture or Associate Company.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("19. ORDERS PASSED BY REGULATORS IMPACTING GOING CONCERN:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`There have been no orders passed by regulators/courts/tribunals which may impact the going concern status or Company operations.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("20. CHANGES IN SHARE CAPITAL:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`There were no changes in the Company’s share capital during the financial year.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("21. STATUTORY AUDITORS:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`M/s. JAGJYOT SINGH & ASSOCIATES, Chartered Accountants (FRN: 333567E), were appointed as Statutory Auditors for a term of one year at the AGM held on ${agmDate}. They have confirmed their eligibility and willingness to be reappointed.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("22. AUDITOR'S REPORT:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`The Auditor’s Report does not contain any qualifications, reservations or adverse remarks. The notes to accounts are self-explanatory.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("23. RELATED PARTY TRANSACTIONS:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`All related party transactions entered into by the Company were in the ordinary course of business and on an arm’s length basis. Hence, disclosure in Form AOC-2 is not required.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("24. DIVIDEND:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`To conserve resources and augment future growth, the Board has not recommended any dividend.`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("25. CONSERVATION OF ENERGY, TECHNOLOGY ABSORPTION, FOREIGN EXCHANGE EARNINGS AND OUTGO:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(A) Conservation of Energy: (i) Steps taken: Not significant due to the nature of operations.`, { align: 'justify' });
    doc.fontSize(11).font('Poppins.ttf').text(`(ii) Alternate energy: Not applicable.`, { align: 'justify' });
    doc.fontSize(11).font('Poppins.ttf').text(`(iii) Capital Investment: Not applicable.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(B) Technology Absorption: (i) Efforts: Nil.`, { align: 'justify' });
    doc.fontSize(11).font('Poppins.ttf').text(`(ii) Benefits: Nil.`, { align: 'justify' });
    doc.fontSize(11).font('Poppins.ttf').text(`(iii) Imported Technology: Nil.`, { align: 'justify' });
    doc.fontSize(11).font('Poppins.ttf').text(`(iv) R&D: Nil.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`(C) Foreign Exchange: (i) Earnings: Nil`, { align: 'justify' });
    doc.fontSize(11).font('Poppins.ttf').text(`(ii) Outgo: Nil`, { align: 'justify' });
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("26. EXTRACT OF ANNUAL RETURN:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`As required under Section 92(3) and Rule 12(1) of the Companies (Management and Administration) Rules, 2014, the extract of Annual Return in Form MGT-9 is attached as `, { align: 'justify', continued: true }).font('Poppins-Bold.ttf').text(`Annexure 'B'.`);
    doc.moveDown(1);
    doc.moveTo(0 + spaceFromEdge, doc.y).lineTo(doc.page.width - spaceFromEdge, doc.y).strokeColor('#a0a0a0').stroke();
    doc.moveDown(1);
    doc.fontSize(11).font('Poppins-Bold.ttf').text("27. ACKNOWLEDGEMENTS:", { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins.ttf').text(`Your Directors wish to thank all stakeholders, employees, consultants, bankers and shareholders for their continued support and confidence in the management of the Company.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(11).font('Poppins-Bold.ttf').text(`For and on behalf of the Board of Directors`, { align: 'justify' });
    doc.fontSize(11).font('Poppins-Bold.ttf').text(companyName, { align: 'justify' });
    doc.fontSize(11).font('Poppins-Bold.ttf').text(`Place: ${place}`, { align: 'justify' });
    doc.fontSize(11).font('Poppins-Bold.ttf').text(`Date: ${date}`, { align: 'justify' });

    for (let i = 0; i < signingDirectors.length; i=i+2) {

        if (i + 1 < signingDirectors.length) {

            doc.moveDown(4);
            const currentY = doc.y;

            doc.fontSize(11).font('Poppins-Bold.ttf').text(signingDirectors[i].name, spaceFromEdge, currentY, {
                width: 250,
                align: 'left'
            });
            doc.fontSize(11).font('Poppins.ttf').text(`Director`);
            doc.fontSize(11).font('Poppins.ttf').text(`DIN: ${signingDirectors[i].din}`);

            doc.fontSize(11).font('Poppins-Bold.ttf').text(signingDirectors[i + 1].name, spaceFromEdge + 270, currentY, {
                width: 250,
                align: 'left'
            });
            doc.fontSize(11).font('Poppins.ttf').text(`Director`);
            doc.fontSize(11).font('Poppins.ttf').text(`DIN: ${signingDirectors[i + 1].din}`);

        }else{
            doc.moveDown(4);
            doc.fontSize(11).font('Poppins-Bold.ttf').text(signingDirectors[i].name, spaceFromEdge, doc.y);
            doc.fontSize(11).font('Poppins.ttf').text(`Director`);
            doc.fontSize(11).font('Poppins.ttf').text(`DIN: ${signingDirectors[i].din}`);
        }
    }

    // --- HEADER AND FOOTER LOGIC (using buffered pages) ---
    let pages = doc.bufferedPageRange();
    for (let i = 0; i < pages.count; i++) {
        doc.switchToPage(i);

        // --- Header ---
        doc.fontSize(15).font('Poppins.ttf');
        doc.text(companyName, doc.page.margins.left, 20, { align: 'left' });
        doc.text("CIN: "+cin, doc.page.margins.left, 40, { align: 'left' });
    }

    doc.end();
}

function buildConsentLetterPDF(res, companyName, companyAddress, incorporationDate, date) {
    const spaceFromEdge = 72; 
    const dateString = `31st March 2026`;

    const doc = new PDFDocument({
        size: 'A4',
        margins: { top: 80, bottom: 80, left: spaceFromEdge, right: spaceFromEdge },
        bufferPages: true, // Crucial for the new header/footer logic
        // permissions: {
        //     printing: 'highResolution', // Allowed printing
        //     modifying: false,
        //     copying: false,
        //     annotating: false,
        //     fillingForms: false,
        //     contentAccessibility: false,
        //     documentAssembly: false
        // },
        // You must provide a password for permissions to be enforced.
        // This password does NOT prevent viewing, only changing permissions.
        // ownerPassword: 'amit_jagjyot'
    });

    doc.pipe(res);

    doc.fontSize(10).font('Poppins-Bold.ttf').text("TO,");
    doc.fontSize(10).font('Poppins.ttf').text("THE BOARD OF DIRECTORS");
    doc.fontSize(10).font('Poppins-Bold.ttf').text(companyName.toUpperCase());
    doc.fontSize(10).font('Poppins.ttf').text(companyAddress);
    doc.moveDown(1);
    doc.fontSize(10).font('Poppins.ttf').text(`Date: ${date}`);
    doc.moveDown(0.5);

    doc.fontSize(10).font('Poppins-Bold.ttf').text("Subject: ",{continued: true}).font('Poppins.ttf').text('Consent to act as First Auditor and Certificate under Section 139(6) of the Companies Act, 2013.', {align: 'justify'});
    doc.moveDown(1);
    doc.fontSize(10).font('Poppins.ttf').text("Dear Sir/Madam,");
    doc.moveDown(0.5);
    doc.fontSize(10).font('Poppins.ttf').text(`We, M/s. JAGJYOT SINGH AND ASSOCIATES, Chartered Accountants, hereby give our consent to be appointed as the First Auditor `, {continued: true, align: 'justify'}).font('Poppins-Bold.ttf').text(`${companyName.toUpperCase()} `, {continued: true, align: 'justify'}).font('Poppins.ttf').text(`under Section 139(6) of the Companies Act, 2013, for the financial year commencing from ${incorporationDate} `, { align: 'justify', continued: true }).font('Poppins-Bold.ttf').text(`(Date of Incorporation) to ${dateString}`, { align: 'justify' });
    doc.moveDown(1);
    doc.fontSize(10).font('Poppins.ttf').text(`Further, pursuant to the provisions of `, { align: 'justify', continued: true }).font('Poppins-Bold.ttf').text(`Section 139(6) and Rule 4 of the Companies (Audit and Auditors) Rules, 2014`, { align: 'justify', continued: true }).font('Poppins.ttf').text(`, we hereby certify that:`, { align: 'justify' });
    doc.moveDown(0.5);

    doc.fontSize(10).font('Poppins.ttf').list([
        'We satisfy the eligibility criteria as specified under Section 141 of the Companies Act, 2013;',
        'We are not disqualified from being appointed as Auditor under the provisions of the Companies Act, 2013, the Chartered Accountants Act, 1949, and the rules or regulations made thereunder;',
        'The proposed appointment is in accordance with the provisions of the Companies Act, 2013;',
        'The proposed appointment is within the limits laid down under the Act;',
        'There are no pending proceedings relating to professional misconduct against the firm or any of its partners under the Chartered Accountants Act, 1949.'
    ], {  listType: 'numbered', paragraphGap: 2, indent: 0, align: 'justify' });
    
    doc.moveDown(0.5);
    doc.fontSize(10).font('Poppins.ttf').text(`We request you to kindly take the above on record and do the needful.`, { align: 'justify' });
    doc.moveDown(0.5);
    doc.fontSize(10).font('Poppins.ttf').text(`Thanking You,`);
    doc.fontSize(10).font('Poppins.ttf').text(`Yours faithfully,`);
    doc.fontSize(10).font('Poppins.ttf').text(`For `,{continued: true}).font('Poppins-Bold.ttf').text(`M/s. JAGJYOT SINGH AND ASSOCIATES`);

    doc.moveDown(0.2);
    doc.image('sign.png', spaceFromEdge, doc.y, { width: 120 });
    doc.moveDown(3.5);

    doc.fontSize(10).font('Poppins.ttf').text('Chartered Accountants');
    doc.fontSize(10).font('Poppins.ttf').text('FRN: 333567E');
    doc.fontSize(10).font('Poppins.ttf').text('CA Jagjyot Singh');
    doc.fontSize(10).font('Poppins.ttf').text('Proprietor');
    doc.fontSize(10).font('Poppins.ttf').text('Membership No.: 319799');
    doc.fontSize(10).font('Poppins.ttf').text('Place: Kolkata');
    // doc.fontSize(10).font('Poppins.ttf').text('Date: '+date);

    // --- HEADER AND FOOTER LOGIC (using buffered pages) ---
    let pages = doc.bufferedPageRange();
    for (let i = 0; i < pages.count; i++) {
        doc.switchToPage(i);

        // --- Header ---
        doc.image('calogo.jpg', 10, 20, { width: 50 });
        doc.fontSize(15).font('Poppins.ttf');
        doc.text("M/s. JAGJYOT SINGH AND ASSOCIATES.", doc.page.margins.left, 20, { align: 'left' });
        doc.text("Firm Registration No. - 333567E", doc.page.margins.left, 40, { align: 'left' });

        // --- Footer ---
        let oldBottomMargin = doc.page.margins.bottom;
        doc.page.margins.bottom = 0 //Dumb: Have to remove bottom margin in order to write into it
        doc.fontSize(12).font('Poppins.ttf').text("PLOT 51, BLOCK BB – 102, SHANTIPALLY, SARAT PARK,", 0, doc.page.height - 65, { align: 'center', width: doc.page.width });
        doc.fontSize(12).font('Poppins.ttf').text("KOLKATA – 700107", 0, doc.page.height - 45, { align: 'center', width: doc.page.width });
        doc.page.margins.bottom = oldBottomMargin;
    }

    // Finalize the PDF and end the stream
    doc.end();
}

module.exports = router;
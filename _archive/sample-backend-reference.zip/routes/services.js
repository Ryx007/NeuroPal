const express = require('express');
const { userVerify } = require('../libs/auth');
const Service = require('../models/serviceModel');
const router = express.Router();

router.get('/list', userVerify, async(req, res)=>{
    try{
        const services = await Service.find({status: true});
        res.json({
            status: true,
            data: services
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/all', userVerify, async(req, res)=>{
    try{
        const services = await Service.find().populate({path: 'template', select: 'name'});
        res.json({
            status: true,
            data: services
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/new', userVerify, async(req, res)=>{
    try{
        const {name, status, template, professional, govt, hsn} = req.body;
        if(!name || !template || !professional || isNaN(govt) || !hsn){
            throw new Error('Missing Data');
        }

        let obj = {
            name: name,
            status: status,
            template: template,
            professional: professional,
            govt: govt,
            hsn: hsn
        }

        const nSrv = await Service.create(obj);
        const data = await Service.findById(nSrv.id).populate({path: 'template', select: 'name'});
        res.json({
            status: true,
            data: data
        })

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/update', userVerify, async(req, res)=>{
    try{
        const {id, name, status, template, professional, govt, hsn} = req.body;
        if(!name || !id || !template || !professional || isNaN(govt) || !hsn){
            throw new Error('Missing Data');
        }

        let obj = {
            name: name,
            status: status,
            template: template,
            professional: professional,
            govt: govt,
            hsn: hsn
        }

        const data = await Service.findByIdAndUpdate(id, obj, {new: true}).populate({path: 'template', select: 'name'});
        res.json({
            status: true,
            data
        })

    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Service ID':e.message
        })
    }
})

module.exports = router;
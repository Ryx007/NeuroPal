const express = require('express');
const RecurringInvoice = require('../models/recurringInvoiceModel');
const RecurringInvoiceItem = require('../models/recurringInvoiceItemModel');
const { getInvoice, generatePDF } = require('../libs/invoice');
const Customer = require('../models/customerModel');
const EmailTemplate = require('../models/emailTemplates');
const Config = require('../models/configModel');
const { sendEmails } = require('../libs/email');
const TemplateHistory = require('../models/templateHistory');
const moment = require('moment');
const ActiveService = require('../models/activeServiceModel');
const { gstServiceId } = require('../libs/common');
const InvoiceItem = require('../models/invoiceItemsModel');
const router = express.Router();

router.get('/recurringInvoice', async(req, res)=>{
    try{
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(today.getDate() + 1); // Start of the next day

        const rInvs = await RecurringInvoice.find({
            endDate: { $gte: today }, // Dates less than the start of tomorrow
            nextDate: { $gte: today, $lt: tomorrow } // Dates matching today
        }).populate({path: 'customer', select: 'name companyName address emails', populate: "state"});

        const configData = await Config.findOne({"name": "recurringInvoiceTemplate"});
        const template = await EmailTemplate.findById(configData.value);

        res.json({
            status: true
        })

        for (const rInv of rInvs) {
            let nextDate = rInv.nextDate;
            if (rInv.intervalType === "day") {
                nextDate.setDate(nextDate.getDate() + parseInt(rInv.interval));
            } else if (rInv.intervalType === "month") {
                nextDate.setMonth(nextDate.getMonth() + parseInt(rInv.interval));
            }
            if (nextDate > rInv.endDate) {
                await RecurringInvoice.findByIdAndUpdate(rInv.id, {nextDate: null, status: false});
            }else{
                await RecurringInvoice.findByIdAndUpdate(rInv.id, {nextDate: nextDate});
            }
            if(rInv.status){
                //gen invoice
                const invItems = await RecurringInvoiceItem.find({invoice: rInv.id});
                const result = await getInvoice(rInv.customer.id, today, invItems, rInv.id, rInv.linkedService?rInv.linkedService:null);

                if(!result.status){
                    console.log(result.message);
                }else{
                    const customerData = rInv.customer;
                    if(customerData.emails.length == 0){
                        continue;
                    }
                    //send mail
                    const invoiceData = result.data;
                    let subject = template.subject;
                    let content = template.content;
                    subject = subject.replace(/{{name}}/g, customerData.name);
                    subject = subject.replace(/{{companyName}}/g, customerData.companyName);
                    subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

                    content = content.replace(/{{name}}/g, customerData.name);
                    content = content.replace(/{{companyName}}/g, customerData.companyName);
                    content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

                    let invPdf = null;
                    if(invoiceData){
                        subject = subject.replace(/{{invoiceNo}}/g, invoiceData.invoiceNo);
                        subject = subject.replace(/{{invoiceDate}}/g, moment(invoiceData.invDate).format('Do MMM YYYY'));
                        subject = subject.replace(/{{invoiceAmount}}/g, "₹ "+parseFloat(invoiceData.total).toFixed(2));

                        content = content.replace(/{{invoiceNo}}/g, invoiceData.invoiceNo);
                        content = content.replace(/{{invoiceDate}}/g, moment(invoiceData.invDate).format('Do MMM YYYY'));
                        content = content.replace(/{{invoiceAmount}}/g, "₹ "+parseFloat(invoiceData.total).toFixed(2));
                        const invoiceItems = await InvoiceItem.find({invoice: invoiceData.id}).populate({path: 'product', select: 'hsn'});
                        const pdfBuffer = await generatePDF(customerData, invoiceData, invoiceItems);
                        invPdf = {
                            filename: invoiceData.invoiceNo+'.pdf',
                            content: pdfBuffer, 
                            contentType: 'application/pdf'
                        }
                    }

                    await sendEmails(customerData.emails, subject, content, template.attachments,invPdf);
                    await TemplateHistory.create({customer: customerData.id, type: "customer", content: content, subject: subject, template: template.id});
                }
            }
        }

    }catch(e){
        console.log(e.message);
    }
})

router.get('/emails', async(req, res)=>{
    try{
        res.json({status: true});

        //2 days old
        const twoDayOld = new Date();
        twoDayOld.setDate(twoDayOld.getDate() - 2);
        const twoDayCustomers = await Customer.find({
            onboardingDate: {
                $gte: new Date(twoDayOld.setHours(0, 0, 0, 0)),
                $lte: new Date(twoDayOld.setHours(23, 59, 59, 999))
            }
        });
        const serviceListEmails = await Config.findOne({name: 'serviceListTemplate'});
        const serviceListTemplate = await EmailTemplate.findById(serviceListEmails.value);
        for (const customerData of twoDayCustomers) {
            if (customerData.emails.length == 0) {
                continue;
            }
            let subject = serviceListTemplate.subject;
            let content = serviceListTemplate.content;
            subject = subject.replace(/{{name}}/g, customerData.name);
            subject = subject.replace(/{{companyName}}/g, customerData.companyName);
            subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

            content = content.replace(/{{name}}/g, customerData.name);
            content = content.replace(/{{companyName}}/g, customerData.companyName);
            content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
            await sendEmails(customerData.emails, subject, content, serviceListTemplate.attachments);
            await TemplateHistory.create({ customer: customerData.id, type: "customer", content: content, subject: subject, template: serviceListTemplate.id });
        }
        
        //7 days
        const sevenDayOld = new Date();
        sevenDayOld.setDate(sevenDayOld.getDate() - 7);
        const sevenDayCustomers = await Customer.find({
            onboardingDate: {
                $gte: new Date(sevenDayOld.setHours(0, 0, 0, 0)),
                $lte: new Date(sevenDayOld.setHours(23, 59, 59, 999))
            },
            compliance: true
        });
        const pTaxEmails = await Config.findOne({name: 'ptaxTemplate'});
        const pTaxTemplate = await EmailTemplate.findById(pTaxEmails.value);
        for (const customerData of sevenDayCustomers) {
            if (customerData.emails.length == 0) {
                continue;
            }
            let subject = pTaxTemplate.subject;
            let content = pTaxTemplate.content;
            subject = subject.replace(/{{name}}/g, customerData.name);
            subject = subject.replace(/{{companyName}}/g, customerData.companyName);
            subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

            content = content.replace(/{{name}}/g, customerData.name);
            content = content.replace(/{{companyName}}/g, customerData.companyName);
            content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
            await sendEmails(customerData.emails, subject, content, pTaxTemplate.attachments);
            await TemplateHistory.create({ customer: customerData.id, type: "customer", content: content, subject: subject, template: pTaxTemplate.id });
        }

        //10 days
        const tenDayOld = new Date();
        tenDayOld.setDate(tenDayOld.getDate() - 10);
        const tenDayCustomers = await Customer.find({
            onboardingDate: {
                $gte: new Date(tenDayOld.setHours(0, 0, 0, 0)),
                $lte: new Date(tenDayOld.setHours(23, 59, 59, 999))
            },
            compliance: true
        });
        const websiteEmails = await Config.findOne({name: 'websiteTemplate'});
        const websiteTemplate = await EmailTemplate.findById(websiteEmails.value);
        for (const customerData of tenDayCustomers) {
            if (customerData.emails.length == 0) {
                continue;
            }
            let subject = websiteTemplate.subject;
            let content = websiteTemplate.content;
            subject = subject.replace(/{{name}}/g, customerData.name);
            subject = subject.replace(/{{companyName}}/g, customerData.companyName);
            subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

            content = content.replace(/{{name}}/g, customerData.name);
            content = content.replace(/{{companyName}}/g, customerData.companyName);
            content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
            await sendEmails(customerData.emails, subject, content, websiteTemplate.attachments);
            await TemplateHistory.create({ customer: customerData.id, type: "customer", content: content, subject: subject, template: websiteTemplate.id });
        }

        //15 days
        const fifteenDayOld = new Date();
        fifteenDayOld.setDate(fifteenDayOld.getDate() - 15);
        const fifteenDayCustomers = await Customer.find({
            onboardingDate: {
                $gte: new Date(fifteenDayOld.setHours(0, 0, 0, 0)),
                $lte: new Date(fifteenDayOld.setHours(23, 59, 59, 999))
            },
            compliance: true
        });
        const startupEmails = await Config.findOne({name: 'startupIndiaTemplate'});
        const startupTemplate = await EmailTemplate.findById(startupEmails.value);
        for (const customerData of fifteenDayCustomers) {
            if (customerData.emails.length == 0) {
                continue;
            }
            let subject = startupTemplate.subject;
            let content = startupTemplate.content;
            subject = subject.replace(/{{name}}/g, customerData.name);
            subject = subject.replace(/{{companyName}}/g, customerData.companyName);
            subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

            content = content.replace(/{{name}}/g, customerData.name);
            content = content.replace(/{{companyName}}/g, customerData.companyName);
            content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
            await sendEmails(customerData.emails, subject, content, startupTemplate.attachments);
            await TemplateHistory.create({ customer: customerData.id, type: "customer", content: content, subject: subject, template: startupTemplate.id });
        }

        //20 days
        const twentyDayOld = new Date();
        twentyDayOld.setDate(twentyDayOld.getDate() - 20);
        const twentyDayCustomers = await Customer.find({
            onboardingDate: {
                $gte: new Date(twentyDayOld.setHours(0, 0, 0, 0)),
                $lte: new Date(twentyDayOld.setHours(23, 59, 59, 999))
            },
            compliance: true
        });
        const isoEmails = await Config.findOne({name: 'IsoTemplate'});
        const isoTemplate = await EmailTemplate.findById(isoEmails.value);
        for (const customerData of twentyDayCustomers) {
            if (customerData.emails.length == 0) {
                continue;
            }
            let subject = isoTemplate.subject;
            let content = isoTemplate.content;
            subject = subject.replace(/{{name}}/g, customerData.name);
            subject = subject.replace(/{{companyName}}/g, customerData.companyName);
            subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

            content = content.replace(/{{name}}/g, customerData.name);
            content = content.replace(/{{companyName}}/g, customerData.companyName);
            content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
            await sendEmails(customerData.emails, subject, content, isoTemplate.attachments);
            await TemplateHistory.create({ customer: customerData.id, type: "customer", content: content, subject: subject, template: isoTemplate.id });
        }

        //120 days
        const incDayOld = new Date();
        incDayOld.setDate(incDayOld.getDate() - 120);
        const incDayOld1 = new Date();
        incDayOld1.setDate(incDayOld1.getDate() - 150);
        const incCustomers = await Customer.find({
            $or: [
                {
                    incorporationDate: {
                        $gte: new Date(incDayOld.setHours(0, 0, 0, 0)),
                        $lte: new Date(incDayOld.setHours(23, 59, 59, 999))
                    }
                },
                {
                    incorporationDate: {
                        $gte: new Date(incDayOld1.setHours(0, 0, 0, 0)),
                        $lte: new Date(incDayOld1.setHours(23, 59, 59, 999))
                    }
                }
            ],
            compliance: true,
            newlyIncorporated: true
        });
   
        const incEmails = await Config.findOne({name: 'Inc20Template'});
        const incTemplate = await EmailTemplate.findById(incEmails.value);
        for (const customerData of incCustomers) {
            if (customerData.emails.length == 0) {
                continue;
            }
        
        	let incDate = new Date(customerData.incorporationDate);
        	incDate.setDate(incDate.getDate() + 180);
            
        	let subject = incTemplate.subject;
            let content = incTemplate.content;
            subject = subject.replace(/{{name}}/g, customerData.name);
            subject = subject.replace(/{{companyName}}/g, customerData.companyName);
            subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
        	subject = subject.replace(/{{complianceExpiryDate}}/g, moment(incDate).format('Do MMM YYYY'));

            content = content.replace(/{{name}}/g, customerData.name);
            content = content.replace(/{{companyName}}/g, customerData.companyName);
            content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
        	content = content.replace(/{{complianceExpiryDate}}/g, moment(incDate).format('Do MMM YYYY'));
            await sendEmails(customerData.emails, subject, content, incTemplate.attachments);
            await TemplateHistory.create({ customer: customerData.id, type: "customer", content: content, subject: subject, template: incTemplate.id });
        }

    }catch(e){
        console.log(e);
    }
})

router.get('/gstemails', async(req, res)=>{
    try{
        res.json({
            status: true
        })
        const today = new Date();
        if (today.getDate() !== 2) {
            return;
        }

        const activeGsts = await ActiveService.find({service: gstServiceId, status: true}).populate('customer');
        const gstEmails = await Config.findOne({name: 'gstTemplate'});
        const gstTemplate = await EmailTemplate.findById(gstEmails.value);
        for (const activeSrv of activeGsts) {
            const customerData = activeSrv.customer;
            if (customerData.emails.length == 0) {
                continue;
            }
            let subject = gstTemplate.subject;
            let content = gstTemplate.content;
            subject = subject.replace(/{{name}}/g, customerData.name);
            subject = subject.replace(/{{companyName}}/g, customerData.companyName);
            subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));

            content = content.replace(/{{name}}/g, customerData.name);
            content = content.replace(/{{companyName}}/g, customerData.companyName);
            content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
            await sendEmails(customerData.emails, subject, content, gstTemplate.attachments);
            await TemplateHistory.create({ customer: customerData.id, type: "customer", content: content, subject: subject, template: gstTemplate.id });
        }
    }catch(e){
        console.log(e.message);
    }
})

module.exports = router;

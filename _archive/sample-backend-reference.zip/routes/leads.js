const express = require('express');
const { userVerify } = require('../libs/auth');
const Lead = require('../models/leadModel');
const LeadNote = require('../models/leadNotes');
const User = require('../models/userModel');
const TemplateHistory = require('../models/templateHistory');
const EmailTemplate = require('../models/emailTemplates');
const { sendEmails } = require('../libs/email');
const { doubletickFrom, doubletickApiKey } = require('../libs/common');
const { default: axios } = require('axios');
const router = express.Router();

router.post('/lists/:page', userVerify, async(req, res)=>{
    try{
        const page = parseInt(req.params.page) || 1;
        if(!page){
            throw new Error('Missing Page Number');
        }
        if (Number.isNaN(page) || !Number.isInteger(page) || page < 1) {
            throw new Error('Invalid Page Number');
        }

        const {service, agent, source, type, priority, response, name, start, end, dtype} = req.body;

        const options = {
            page: page,
            limit: 50,
            sort: { modified: -1 },
            populate: [{path: 'assigned', select: 'name'},{path: 'service', select: 'name'}]
        };

        let query = {};
        if(name && name.trim() != ""){
            const regex = new RegExp(name, 'i');
            query.$or = [
                { name: regex },
                { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                { companyName: regex }
            ];
        }
        if(start > 0 && end > 0 && end > start){
            const dateFieldMap = {
                "created": "modified",
                "lastFollowup": "lastFollowup",
                "nextFollowup": "nextFollowup"
            };
            const dateField = dateFieldMap[dtype];
            if (dateField) {
                query[dateField] = { $gte: start, $lte: end };
            }
        }
        if (service && Array.isArray(service) && service.length > 0) {
            query.service = { $in: service };
        }
        if (agent && Array.isArray(agent) && agent.length > 0) {
            query.assigned = { $in: agent };
        }
        if (source && Array.isArray(source) && source.length > 0) {
            query.source = { $in: source };
        }
        if (type && Array.isArray(type) && type.length > 0) {
            query.type = { $in: type };
        }
        if (priority && Array.isArray(priority) && priority.length > 0) {
            query.priority = { $in: priority };
        }
        if (response && Array.isArray(response) && response.length > 0) {
            query.response = { $in: response };
        }

        const leads = await Lead.paginate(query, options);
        res.json({
            status: true,
            data: leads
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.post('/new', userVerify, async(req, res)=>{
    try{
        const {name, phone, service, source, type, priority, agent, company, address, state} = req.body;
        if(!name || !phone || !service || !source || !type || !priority || !agent){
            throw new Error('Missing Data');
        }

        let obj = {
            name: name,
            phone: phone,
            companyName: company,
            source: source,
            type: type,
            address: address
        }
        if(service != 'none'){
            obj.service = service;
        }
        if(agent != 'none'){
            obj.assigned = agent;
        }
        if(priority != 'none'){
            obj.priority = priority;
        }
        if(state != ""){
            obj.state = state;
        }

        const data = await Lead.create(obj);
        res.json({
            status: true,
            data: data
        })

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/details/:id', userVerify, async(req, res)=>{
    try{
        const id = req.params.id;
        const leadData = await Lead.findById(id).populate({path: 'service', select: 'name'}).populate({path: 'assigned', select: 'name'}).populate({path: 'state', select: 'name'});
        const notes = await LeadNote.find({lead: id}).sort({created: -1}).populate({path: 'agent', select: 'name'}).populate({path: 'template', select: 'name'});

        res.json({
            status: true,
            data: leadData,
            notes: notes
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Lead ID':e.message
        })
    }
})

router.post('/emails', userVerify, async(req, res)=>{
    try{
        const {id, emails} = req.body;
        await Lead.findByIdAndUpdate(id, {emails: emails});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Lead ID':e.message
        })
    }
})

router.post('/agent', userVerify, async(req, res)=>{
    try{
        const {id, agent} = req.body;
        const agentData = await User.findById(agent);
        if(!agentData){
            throw new Error('Agent not found');
        }
        const leadData = await Lead.findByIdAndUpdate(id, {assigned: agent});
        await LeadNote.create({lead:id, agent: leadData.assigned, note: "Assigned to "+agentData.name, call: false});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Lead ID':e.message
        })
    }
})

router.post('/followup', userVerify, async(req, res)=>{
    try{
        const {id, date, doCall} = req.body;
        await Lead.findByIdAndUpdate(id, {nextFollowup: date, doCall: doCall});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Lead ID':e.message
        })
    }
})

router.post('/update', userVerify, async(req, res)=>{
    try{
        const {name, phone, address, state, service, source, type, priority, company, id, response} = req.body;
        if(!name || !phone || !service || !source || !type || !priority || !response){
            throw new Error('Missing Data');
        }
        let obj = {
            name: name,
            phone: phone,
            companyName: company,
            source: source,
            type: type,
            address: address
        }
        if(service != 'none'){
            obj.service = service;
        }
        if(priority != 'none'){
            obj.priority = priority;
        }
        if(state != ""){
            obj.state = state;
        }
        if(response != ""){
            obj.response = response;
        }
        await Lead.findByIdAndUpdate(id, obj);
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Lead ID':e.message
        })
    }
})

router.post('/note', userVerify, async(req, res)=>{
    try{
        const {id, note, isCall} = req.body;
        const leadData = await Lead.findById(id).select('assigned');
        if(!leadData){
            throw new Error('Invalid ID');
        }
        if(!leadData.assigned){
            throw new Error('Lead not assigned to any agent');
        }

        await LeadNote.create({lead:id, agent: leadData.assigned, note: note, call: isCall});
        await Lead.findByIdAndUpdate(id, {lastFollowup: Date.now(), interacted: true});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Lead ID':e.message
        })
    }
})

router.post('/sendemail', userVerify, async(req, res)=>{
    try{
        let {id, content, subject, tid} = req.body;
        if(!id || !content || !subject || !tid){
            throw new Error('Missing Data');
        }
        const leadData = await Lead.findById(id);
        if(!leadData){
            throw new Error('Invalid Lead');
        }
        if(!leadData.assigned){
            throw new Error('Lead not assigned to any agent');
        }
        const emails = leadData.emails;
        if(!emails || emails.length == 0){
            throw new Error('No emails added to this lead');
        }
        let company = "";
        if(leadData.companyName){
            company = leadData.companyName;
        }
        let address = "";
        if(leadData.address){
            address = leadData.address;
        }
        subject = subject.replace(/{{name}}/g, leadData.name);
        subject = subject.replace(/{{companyName}}/g, company);
        subject = subject.replace(/{{address}}/g, address.replace(/\n/g, " "));

        content = content.replace(/{{name}}/g, leadData.name);
        content = content.replace(/{{companyName}}/g, company);
        content = content.replace(/{{address}}/g, address.replace(/\n/g, " "));

        //add to leadnote
        await LeadNote.create({lead:id, agent: leadData.assigned, templateSubject: subject, note: content, template: tid});
        await Lead.findByIdAndUpdate(id, {lastFollowup: Date.now(), interacted: true});
        await TemplateHistory.create({lead: id, type: "lead", content: content, subject: subject, template: tid, user: leadData.assigned});

        res.json({
            status: true
        })
        const templateData = await EmailTemplate.findById(tid).select('attachments');
        await sendEmails(emails, subject, content, templateData.attachments);

    }catch(e){
        res.json({ 
            status: false,
            message: e.name == "CastError"?'Invalid Lead ID':e.message
        })
    }
})

router.post('/whatsapptemplate', userVerify, async(req, res)=>{
    try{
        const {id, obj} = req.body;
        if(!id || !obj){
            throw new Error('Missing Data');
        }
        const leadData = await Lead.findById(id).select('phone assigned');
        if(!leadData){
            throw new Error('Invalid Lead');
        }
        if(!leadData.assigned){
            throw new Error('Lead not assigned to any agent');
        }
        let waObj = {
            messages: [
                {
                    content: obj,
                    from: doubletickFrom,
                    to: '+91'+leadData.phone
                }
            ]
        }

        const resp = await axios.post("https://public.doubletick.io/whatsapp/message/template", waObj, {headers: {Accept: "application/json", Authorization: doubletickApiKey}});

        //add to leadnote
        await LeadNote.create({lead:id, agent: leadData.assigned, note: "Whatsapp Template: "+obj.templateName});
        await Lead.findByIdAndUpdate(id, {lastFollowup: Date.now(), interacted: true});

        res.json({
            status: true,
            data: resp.data
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

module.exports = router;

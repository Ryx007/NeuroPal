const express = require('express');
const { userVerify } = require('../libs/auth');
const Lead = require('../models/leadModel');
const Customer = require('../models/customerModel');
const Invoice = require('../models/invoiceModel');
const Payment = require('../models/paymentModel');
const Compliance = require('../models/complianceModel');
const AccountantJob = require('../models/accountantJobsModel');
const LeadNote = require('../models/leadNotes');

const router = express.Router();

router.post('/', userVerify, async(req, res)=>{
    try{
        const {start, end} = req.body;
        if(start <= 0 || end <= 0 || end < start){
            throw new Error('Invalid Date');
        } 

        const generateDates = (start, end) => {
            const dates = [];
            let currentDate = new Date(start);
        	currentDate.setDate(currentDate.getDate() + 1);
            const lastDate = new Date(end);
        	lastDate.setDate(lastDate.getDate() + 1);

            while (currentDate <= lastDate) {
                dates.push(currentDate.toISOString().split('T')[0]); // Format as YYYY-MM-DD
                currentDate.setDate(currentDate.getDate() + 1);
            }
            return dates;
        };
        const allDates = generateDates(start, end);
        const fillMissingDates = (data, dates) => {
            return dates.map(date => {
                const matchingData = data.find(d => d.date === date);
                return matchingData ? matchingData : { date, value: 0 };
            });
        };

        const leadResult = await Lead.aggregate([
            {
                $match: {
                    created: { $gte: start, $lte: end }
                }
            },
            {
                $facet: {
                    totalLeads: [{ $count: "count" }],
                    leadsNotInteracted: [
                        { $match: { interacted: false } },
                        { $count: "count" }
                    ],
                    leadsInteracted: [
                        { $match: { interacted: true } },
                        { $count: "count" }
                    ],
                    hotLeads: [
                        { $match: { type: "hot" } },
                        { $count: "count" }
                    ],
                    coldLeads: [
                        { $match: { type: "cold" } },
                        { $count: "count" }
                    ]
                }
            },
            {
                $project: {
                    totalLeads: { $ifNull: [{ $arrayElemAt: ["$totalLeads.count", 0] }, 0] },
                    leadsNotInteracted: { $ifNull: [{ $arrayElemAt: ["$leadsNotInteracted.count", 0] }, 0] },
                    leadsInteracted: { $ifNull: [{ $arrayElemAt: ["$leadsInteracted.count", 0] }, 0] },
                    hotLeads: { $ifNull: [{ $arrayElemAt: ["$hotLeads.count", 0] }, 0] },
                    coldLeads: { $ifNull: [{ $arrayElemAt: ["$coldLeads.count", 0] }, 0] }
                }
            }
        ]);
        const customerResult = await Customer.aggregate([
            {
                $match: {
                    onboardingDate: { $gte: new Date(start), $lte: new Date(end)}
                }
            },
            {
                $facet: {
                    totalCustomers: [{ $count: "count" }],
                    complianceCustomer: [
                        { $match: { compliance: true } },
                        { $count: "count" }
                    ]
                }
            },
            {
                $project: {
                    totalCustomers: { $ifNull: [{ $arrayElemAt: ["$totalCustomers.count", 0] }, 0] },
                    complianceCustomer: { $ifNull: [{ $arrayElemAt: ["$complianceCustomer.count", 0] }, 0] },
                }
            }
        ]);

        let invoiceResult = await Invoice.aggregate([
            {
                $match: {
                    invDate: { $gte: new Date(start), $lte: new Date(end) }
                }
            },
            {
                $group: {
                    _id: null, // Group all documents into a single group
                    totalInvoices: { $sum: 1 }, // Count total invoices
                    invTotal: { $sum: "$total" }, // Sum of the `total` field
                    invDue: { $sum: "$due" }, // Sum of the `due` field
                    countDues: {
                        $sum: {
                            $cond: [{ $gt: ["$due", 0] }, 1, 0] // Count invoices where `due > 0`
                        }
                    }
                }
            },
            {
                $project: {
                    _id: 0, // Exclude the `_id` field
                    totalInvoices: 1,
                    invTotal: 1,
                    invDue: 1,
                    countDues: 1
                }
            }
        ]);
        if (invoiceResult.length === 0) {
            invoiceResult = [{
                totalInvoices: 0,
                invTotal: 0,
                invDue: 0,
                countDues: 0
            }];
        }

        let paymentResult = await Payment.aggregate([
            {
                $match: {
                    payDate: { $gte: new Date(start), $lte: new Date(end) }
                }
            },
            {
                $group: {
                    _id: null,
                    totalPaymentCount: { $sum: 1 }, 
                    totalPaymentAmount: { $sum: "$amount" } 
                }
            },
            {
                $project: {
                    _id: 0, 
                    totalPaymentCount: 1,
                    totalPaymentAmount: 1
                }
            }
        ]);
        if (paymentResult.length === 0) {
            paymentResult = [{
                totalPaymentCount: 0,
                totalPaymentAmount: 0
            }];
        }

        const currentDate = new Date();
        let complianceResult = await Compliance.aggregate([
            {
                $lookup: {
                    from: "complianceconfigs", // Name of the ComplianceConfig collection
                    localField: "compliance",
                    foreignField: "_id",
                    as: "complianceConfig"
                }
            },
            // Unwind the joined complianceConfig array (since $lookup returns an array)
            {
                $unwind: "$complianceConfig"
            },
            // Group and calculate counts
            {
                $group: {
                    _id: null, // Group all documents into a single group
                    complianceToBeDone: {
                        $sum: {
                            $cond: [{ $eq: ["$status", "To Be Done"] }, 1, 0] // Count where status is "To Be Done"
                        }
                    },
                    complianceOngoing: {
                        $sum: {
                            $cond: [{ $eq: ["$status", "Ongoing"] }, 1, 0]
                        }
                    },
                    expiredCompliance: {
                        $sum: {
                            $cond: [
                                {
                                    $and: [
                                        { $eq: ["$status", "To Be Done"] }, // Status is "To Be Done"
                                        { $lt: ["$complianceConfig.expiry", currentDate] } // Expiry date is in the past
                                    ]
                                },
                                1,
                                0
                            ]
                        }
                    }
                }
            },
            // Format the output
            {
                $project: {
                    _id: 0, // Exclude the `_id` field
                    complianceToBeDone: 1,
                    complianceOngoing: 1,
                    expiredCompliance: 1
                }
            }
        ]);

        // If no records are found, return default values
        if (complianceResult.length === 0) {
            complianceResult = [{
                complianceToBeDone: 0,
                complianceOngoing: 0,
                expiredCompliance: 0
            }];
        }

        let jobResult = await AccountantJob.aggregate([
            {
                $match: {
                    status: { $in: ["To Be Done", "Ongoing"] } // Filter for relevant statuses
                }
            },
            // Group and calculate counts
            {
                $group: {
                    _id: null, // Group all documents into a single group
                    jobToBeDone: {
                        $sum: {
                            $cond: [{ $eq: ["$status", "To Be Done"] }, 1, 0] // Count where status is "To Be Done"
                        }
                    },
                    expiredJobs: {
                        $sum: {
                            $cond: [
                                {
                                    $and: [
                                        { $eq: ["$status", "To Be Done"] }, // Status is "To Be Done"
                                        { $lt: ["$expiryDate", currentDate] } // Expiry date is in the past
                                    ]
                                },
                                1,
                                0
                            ]
                        }
                    },
                    jobOngoing: {
                        $sum: {
                            $cond: [{ $eq: ["$status", "Ongoing"] }, 1, 0] // Count where status is "Ongoing"
                        }
                    }
                }
            },
            // Format the output
            {
                $project: {
                    _id: 0, // Exclude the `_id` field
                    jobToBeDone: 1,
                    expiredJobs: 1,
                    jobOngoing: 1
                }
            }
        ]);

        if (jobResult.length === 0) {
            jobResult = [{
                jobToBeDone: 0,
                expiredJobs: 0,
                jobOngoing: 0
            }];
        }

        let data = {
            ...leadResult[0],
            ...customerResult[0],
            ...invoiceResult[0],
            ...paymentResult[0],
            ...complianceResult[0],
            ...jobResult[0]
        }

        //graph
        const leadData = await Lead.aggregate([
            {
                $match: {
                    created: { $gte: start, $lte: end }
                }
            },
            {
                $group: {
                    _id: {
                        $dateToString: { format: "%Y-%m-%d", date: { $toDate: "$created" } }
                    },
                    value: { $sum: 1 }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const leadGraph = fillMissingDates(
            leadData.map(day => ({ date: day._id, value: day.value })),
            allDates
        );

        const notesData = await LeadNote.aggregate([
            {
                $match: {
                    created: { $gte: start, $lte: end }
                }
            },
            {
                $group: {
                    _id: { 
                        date: { $dateToString: { format: "%Y-%m-%d", date: { $toDate: "$created" } } }, 
                        lead: "$lead"
                    }
                }
            },
            {
                $group: {
                    _id: "$_id.date",
                    noteCount: { $sum: 1 }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const notegraph = fillMissingDates(
            notesData.map(day => ({ date: day._id, value: day.noteCount })),
            allDates
        );

        const salesData = await Invoice.aggregate([
            {
                $match: {
                    invDate: { $gte: new Date(start), $lte: new Date(end) }
                }
            },
            {
                $group: {
                    _id: { $dateToString: { format: "%Y-%m-%d", date: "$invDate" } },
                    salesCount: { $sum: 1 },
                    totalSales: { $sum: "$price" }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const salesGraph = fillMissingDates(
            salesData.map(day => ({ date: day._id, value: day.totalSales })),
            allDates
        );
        const salesCountGraph = fillMissingDates(
            salesData.map(day => ({ date: day._id, value: day.salesCount })),
            allDates
        );

        res.json({
            status: true,
            data: data,
            graph: {
                leads: leadGraph,
                notes: notegraph,
                sales: salesGraph,
                salesCount: salesCountGraph
            }
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/comparegraph', userVerify, async(req, res) => {
    try {
        const { start, end, start2, end2} = req.body;
        const generateDates = (start, end) => {
            const dates = [];
            let currentDate = new Date(start);
        	currentDate.setDate(currentDate.getDate() + 1);
            const lastDate = new Date(end);
        	lastDate.setDate(lastDate.getDate() + 1);

            while (currentDate <= lastDate) {
                dates.push(currentDate.toISOString().split('T')[0]); // Format as YYYY-MM-DD
                currentDate.setDate(currentDate.getDate() + 1);
            }
            return dates;
        };
        const fillMissingDates = (data, dates) => {
            return dates.map(date => {
                const matchingData = data.find(d => d.date === date);
                return matchingData ? matchingData : { date, value: 0 };
            });
        }

        const allDates = generateDates(start, end);
        const allDates2 = generateDates(start2, end2);

        const leadData = await Lead.aggregate([
            {
                $match: {
                    created: { $gte: start, $lte: end }
                }
            },
            {
                $group: {
                    _id: {
                        $dateToString: { format: "%Y-%m-%d", date: { $toDate: "$created" } }
                    },
                    value: { $sum: 1 }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const leadGraph = fillMissingDates(
            leadData.map(day => ({ date: day._id, value: day.value })),
            allDates
        );

        const notesData = await LeadNote.aggregate([
            {
                $match: {
                    created: { $gte: start, $lte: end }
                }
            },
            {
                $group: {
                    _id: { 
                        date: { $dateToString: { format: "%Y-%m-%d", date: { $toDate: "$created" } } }, 
                        lead: "$lead"
                    }
                }
            },
            {
                $group: {
                    _id: "$_id.date",
                    noteCount: { $sum: 1 }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const notegraph = fillMissingDates(
            notesData.map(day => ({ date: day._id, value: day.noteCount })),
            allDates
        );

        const salesData = await Invoice.aggregate([
            {
                $match: {
                    invDate: { $gte: new Date(start), $lte: new Date(end) }
                }
            },
            {
                $group: {
                    _id: { $dateToString: { format: "%Y-%m-%d", date: "$invDate" } },
                    salesCount: { $sum: 1 },
                    totalSales: { $sum: "$price" }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const salesGraph = fillMissingDates(
            salesData.map(day => ({ date: day._id, value: day.totalSales })),
            allDates
        );
        const salesCountGraph = fillMissingDates(
            salesData.map(day => ({ date: day._id, value: day.salesCount })),
            allDates
        );

        const leadData2 = await Lead.aggregate([
            {
                $match: {
                    created: { $gte: start2, $lte: end2 }
                }
            },
            {
                $group: {
                    _id: {
                        $dateToString: { format: "%Y-%m-%d", date: { $toDate: "$created" } }
                    },
                    value: { $sum: 1 }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const leadGraph2 = fillMissingDates(
            leadData2.map(day => ({ date: day._id, value: day.value })),
            allDates2
        );

        const notesData2 = await LeadNote.aggregate([
            {
                $match: {
                    created: { $gte: start2, $lte: end2 }
                }
            },
            {
                $group: {
                    _id: { 
                        date: { $dateToString: { format: "%Y-%m-%d", date: { $toDate: "$created" } } }, 
                        lead: "$lead"
                    }
                }
            },
            {
                $group: {
                    _id: "$_id.date",
                    noteCount: { $sum: 1 }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const notegraph2 = fillMissingDates(
            notesData2.map(day => ({ date: day._id, value: day.noteCount })),
            allDates2
        );

        const salesData2 = await Invoice.aggregate([
            {
                $match: {
                    invDate: { $gte: new Date(start2), $lte: new Date(end2) }
                }
            },
            {
                $group: {
                    _id: { $dateToString: { format: "%Y-%m-%d", date: "$invDate" } },
                    salesCount: { $sum: 1 },
                    totalSales: { $sum: "$price" }
                }
            },
            {
                $sort: { _id: 1 }
            }
        ]);
        const salesGraph2 = fillMissingDates(
            salesData2.map(day => ({ date: day._id, value: day.totalSales })),
            allDates2
        );
        const salesCountGraph2 = fillMissingDates(
            salesData2.map(day => ({ date: day._id, value: day.salesCount })),
            allDates2
        );

        res.json({
            status: true,
            data: {
                leads: leadGraph,
                notes: notegraph,
                sales: salesGraph,
                salesCount: salesCountGraph,
                leads2: leadGraph2,
                notes2: notegraph2,
                sales2: salesGraph2,
                salesCount2: salesCountGraph2
            }
        });

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

module.exports = router;
const express = require('express');
const { userVerify, customerVerify } = require('../libs/auth');
const State = require('../models/stateModel');
const FinancialYear = require('../models/financialYearModel');
const Compliance = require('../models/complianceModel');
const Customer = require('../models/customerModel');
const UAParser = require('ua-parser-js');
const bcrypt = require('bcrypt');
const User = require('../models/userModel');
const Session = require('../models/sessionModel');
const router = express.Router();

router.get('/states', userVerify, async(req, res)=>{
    try{
        const states = await State.find();
        res.json({
            status: true,
            data: states
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/financialyears', userVerify, async(req, res)=>{
    try{
        const fy = await FinancialYear.find().select('name').sort({name: -1});
        res.json({
            status: true,
            data: fy
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/compliances/:fid/:page', userVerify, async(req, res)=>{
    try{
        const page = parseInt(req.params.page) || 1;
        const financialYear = req.params.fid;
        if(!page){
            throw new Error('Missing Page Number');
        }
        if (Number.isNaN(page) || !Number.isInteger(page) || page < 1) {
            throw new Error('Invalid Page Number');
        }

        const {search, type, start, end, status, accountant} = req.body;

        const options = {
            page: page,
            limit: 50,
            sort: { _id: -1 },
            populate: [{path: 'compliance', select: 'name expiry new days'},{path: 'customer', select: 'name phone companyName incorporationDate'},{path: 'accountant', select: 'name'}]
        };

        let query = {financialYear: financialYear};

        if(search && search.trim() != ""){
            const regex = new RegExp(search, 'i');
            const matchingCustomers = await Customer.find({
                $or: [
                    { name: { $regex: regex } },
                    { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                    { companyName: { $regex: regex } }
                ]
            }).select('_id');

            const userIds = matchingCustomers.map(customer => customer._id);
            query.customer = { $in: userIds } ;
        }
        
        if (type && Array.isArray(type) && type.length > 0) {
            query.compliance = { $in: type };
        }
        if(start > 0 && end > 0 && end > start){
            query.doneOn = { $gte: new Date(start), $lte: new Date(end) };
        }
        if (status && Array.isArray(status) && status.length > 0) {
            query.status = { $in: status };
        }
        if (accountant && Array.isArray(accountant) && accountant.length > 0) {
            query.accountant = { $in: accountant };
        }

        const data = await Compliance.paginate(query, options);

        res.json({
            status: true,
            data: data
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/config', userVerify, async(req, res)=>{
    try{
        const user = await User.findById(req.userid);
        if(!user){
            throw new Error('User not found');
        }
        res.json({
            status: true,
            data: {
                name: user.name
            }
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.get('/customerconfig', customerVerify, async(req, res)=>{
    try{
        const customer = await Customer.findById(req.userid).select('_id name');
        if(!customer){
            throw new Error('Customer not found');
        }
        res.json({
            status: true,
            data: {
                name: customer.name
            }
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.post('/login', async(req, res)=>{
    try{
        if(!req.body.phone || !req.body.password){
            throw new Error('Phone Number or Password Missing');
        }
        const {phone, password} = req.body;
        const user = await User.findOne({phone});
        if(!user){
            throw new Error('Invalid Phone Number');
        }
        if(user.type != "admin"){
            throw new Error("User is not admin");
        }
        if(!user.status){
            throw new Error("User is disabled");
        }
        const pchk = await bcrypt.compare(password, user.password);
        if(!pchk){
            throw new Error('Invalid Password');
        }
        const deviceData = UAParser(req.headers['user-agent']);
        const deviceName = `${deviceData.browser.name} ${deviceData.browser.version} on ${deviceData.os.name} ${deviceData.os.version}`;

        const session = await Session.create({type: 'admin', user: user._id, device: deviceName});

        res.json({
            status: true,
            data: {
                userName: user.name,
                userId: user._id,
                session: session._id
            }
        });
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/customerlogin', async(req, res)=>{
    try{
        if(!req.body.username || !req.body.password){
            throw new Error('Username or Password Missing');
        }
        const {username, password} = req.body;
        const customer = await Customer.findOne({username}).select('password name phone compliance');
        if(!customer){
            throw new Error('Invalid Username');
        }
        if(!customer.compliance){
            throw new Error("Annual Compliance not subscribed");
        }
        if(customer.password !== password){
            throw new Error('Invalid Password');
        }
        const deviceData = UAParser(req.headers['user-agent']);
        const deviceName = `${deviceData.browser.name} ${deviceData.browser.version} on ${deviceData.os.name} ${deviceData.os.version}`;

        const session = await Session.create({type: 'customer', user: customer._id, device: deviceName});

        res.json({
            status: true,
            data: {
                userName: customer.name,
                userId: customer._id,
                session: session._id
            }
        });
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/logout', userVerify, async(req, res)=>{
    try{
        await Session.deleteOne({_id: req.session});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/customerlogout', customerVerify, async(req, res)=>{
    try{
        await Session.deleteOne({_id: req.session});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

module.exports = router;
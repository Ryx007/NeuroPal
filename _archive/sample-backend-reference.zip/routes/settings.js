const express = require('express');
const { userVerify } = require('../libs/auth');
const FinancialYear = require('../models/financialYearModel');
const ComplianceConfig = require('../models/complianceConfigModel');
const Config = require('../models/configModel');
const ApiCount = require('../models/apiCountModel');
const router = express.Router();

router.get('/financialyears', userVerify, async(req, res)=>{
    try{
        const data = await FinancialYear.find().sort({name: 1});
        res.json({
            status: true,
            data: data
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/compliances/:fid', userVerify, async(req, res)=>{
    try{
        const fid = req.params.fid;
        const data = await ComplianceConfig.find({financialYear: fid}).sort({expiry: 1}).populate({path: 'expiryTemplate', select: 'name'}).populate({path: 'completeTemplate', select: 'name'});
        res.json({
            status: true,
            data: data
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/financialyear', userVerify, async(req, res)=>{
    try{
        const {id, name} = req.body;
        if(!name){
            throw new Error('Missing Data');
        }
        if(id){
            await FinancialYear.findByIdAndUpdate(id, {name});
        }else{
            await FinancialYear.create({name});
        }
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/compliance', userVerify, async(req, res)=>{
    try{
        const {id, name, expiry, newInc, expiryTemplate, completeTemplate, financialYear, isExpiry, days} = req.body;
        if(!name || !expiryTemplate || !completeTemplate || !financialYear){
            throw new Error('Missing Data');
        }
        let cexpiry = null;
        if(expiry && isExpiry){
            cexpiry = new Date(expiry);
        }
        let cdays = null;
        if(newInc && !isExpiry){
            cdays = days;
        }
        let obj = {
            name, 
            expiry: cexpiry,
            new: newInc,
            days: cdays,
            expiryTemplate: expiryTemplate=="None"?null:expiryTemplate,
            completeTemplate: completeTemplate=="None"?null:completeTemplate,
            financialYear: financialYear
        }

        if(id){
            await ComplianceConfig.findByIdAndUpdate(id, obj);
        }else{
            await ComplianceConfig.create(obj);
        }

        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/list', userVerify, async(req, res)=>{
    try{
        const configs = await Config.find();
        const transformedConfigs = configs.reduce((acc, config) => {
            acc[config.name] = config.value;
            return acc;
        }, {});

        res.json({
            status: true,
            data: transformedConfigs
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/update', userVerify, async(req, res)=>{
    try{
        const {data} = req.body;

        for (let [name, value] of Object.entries(data)) {
            if(name == "invoice_no"){
            	value = parseInt(value);
            }
            await Config.updateOne(
                { name },
                { $set: { value } }
            );
        }

        res.json({status: true});
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/emailcount', userVerify, async(req, res)=>{
    try{
        const {start, end} = req.body;
        if (!(start > 0 && end > 0 && end > start)) {
            throw new Error("Invalid Date");
        }

        const data = await ApiCount.find({
            type: "email",
            date: { $gte: new Date(start), $lte: new Date(end) },
        });

        const total = await ApiCount.aggregate([
            {
                $match: {
                    type: "email",
                    date: { $gte: new Date(start), $lte: new Date(end) },
                },
            },
            {
                $group: {
                    _id: null,
                    total: { $sum: "$count" },
                },
            },
        ]);

        res.json({
            status: true,
            data: data,
            total: total.length > 0 ? total[0].total : 0,
        });
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

module.exports = router;

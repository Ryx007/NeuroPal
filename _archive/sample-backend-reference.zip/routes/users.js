const express = require('express');
const { userVerify } = require('../libs/auth');
const User = require('../models/userModel');
const bcrypt = require('bcrypt');
const router = express.Router();

router.get('/lists', userVerify, async(req, res)=>{
    try{
        const users = await User.find();
        res.json({
            status: true,
            data: users
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/agents', userVerify, async(req, res)=>{
    try{
        const agents = await User.find({type: 'agent', status: true});
        res.json({
            status: true,
            data: agents
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/accountants', userVerify, async(req, res)=>{
    try{
        const accountants = await User.find({type: 'accountant', status: true});
        res.json({
            status: true,
            data: accountants
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/new', userVerify, async(req, res)=>{
    try{
        const {name, status, phone, type, password} = req.body;
        if(!name || !password || !type || isNaN(phone)){
            throw new Error('Missing Data');
        }

        let obj = {
            name: name,
            status: status,
            phone: phone,
            type: type
        }
        const salt = await bcrypt.genSalt(12);
        const hashedPassword = await bcrypt.hash(password, salt);
        obj.password = hashedPassword;

        const nSrv = await User.create(obj);
        const data = await User.findById(nSrv.id);
        res.json({
            status: true,
            data: data
        })

    }catch(e){
        res.json({
            status: false,
            message: e.code === 11000?'Phone Number already exists':e.message
        })
    }
})

router.post('/edit', userVerify, async(req, res)=>{
    try{
        const {id, name, status, phone, password} = req.body;
        if(!id || !name || isNaN(phone)){
            throw new Error('Missing Data');
        }

        let obj = {
            name: name,
            status: status,
            phone: phone
        }
        if(password != ""){
            const salt = await bcrypt.genSalt(12);
            const hashedPassword = await bcrypt.hash(password, salt);
            obj.password = hashedPassword;
        }

        const data = await User.findByIdAndUpdate(id, obj, {new: true});
        res.json({
            status: true,
            data: data
        })

    }catch(e){
        let msg = e.message;
        if(e.code === 11000){
            msg = "Phone Number already exists";
        }
        if(e.name == "CastError"){
            msg = 'Invalid User ID';
        }
        res.json({
            status: false,
            message: msg
        })
    }
})

module.exports = router;
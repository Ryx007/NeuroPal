const express = require('express');
const { userVerify } = require('../libs/auth');
const EmailTemplate = require('../models/emailTemplates');
const multer = require('multer');
const path = require("path");
const fs = require('fs');
const router = express.Router();

router.post('/lists/:page', userVerify, async(req, res)=>{
    try{
        const page = parseInt(req.params.page) || 1;
        if(!page){
            throw new Error('Missing Page Number');
        }
        if (Number.isNaN(page) || !Number.isInteger(page) || page < 1) {
            throw new Error('Invalid Page Number');
        }

        const {search} = req.body;

        const options = {
            page: page,
            limit: 50,
            sort: { created: -1 }
        };

        let query = {};
        if(search && search.trim() != ""){
            const regex = new RegExp(search, 'i');
            query.$or = [
                { name: regex },
                { subject: regex }
            ];
        }

        const templates = await EmailTemplate.paginate(query, options);
        res.json({
            status: true,
            data: templates
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.get('/list', userVerify, async(req, res)=>{
    try{
        const template = await EmailTemplate.find({status: true});
        res.json({
            status: true,
            data: template
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/new', userVerify, async(req, res)=>{
    try{
        const {name, content, subject, status} = req.body;
        if(!name || !content || !subject){
            throw new Error('Missing Data');
        }

        let obj = {
            name: name,
            content: content,
            subject: subject,
            status: status
        }

        const data = await EmailTemplate.create(obj);
        res.json({
            status: true,
            data: data
        })

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/edit', userVerify, async(req, res)=>{
    try{
        const {id, name, content, subject, status} = req.body;
        if(!id || !name || !content || !subject){
            throw new Error('Missing Data');
        }

        let obj = {
            name: name,
            content: content,
            subject: subject,
            status: status
        }

        const data = await EmailTemplate.findByIdAndUpdate(id, obj, {new: true});
        res.json({
            status: true,
            data: data
        })

    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Template ID':e.message
        })
    }
})

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'attachments/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    },
});
const upload = multer({
    storage: storage,
    limits: { fileSize: 20 * 1024 * 1024 },
}).single('file'); 

router.post('/attachment', userVerify, upload, async(req, res)=>{
    try{
        const {id} = req.body;
        if (!req.file) {
            throw new Error('File not uploaded');
        }
        const obj = {
            filename: req.file.originalname,
            path: req.file.path
        }
        const data = await EmailTemplate.findByIdAndUpdate(
            id,
            { $push: { attachments: obj } },
            { runValidators: true, new: true }
        );

        res.json({
            status: true,
            data: data
        });
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Template ID':e.message
        })
    }
})

router.post('/attachment/delete', userVerify, async(req, res)=>{
    try{
        const {id, aid} = req.body;
        if(!id || !aid) {
            throw new Error('Missing Data');
        }

        const templateData = await EmailTemplate.findOne(
            { _id: id, 'attachments._id': aid },
            { 'attachments.$': 1 }
        );
        if (!templateData) {
            throw new Error('Template or Attachment not found');
        }

        const data = await EmailTemplate.findOneAndUpdate(
            { _id: id },
            { $pull: { attachments: { _id: aid } } },
            {new: true}
        );

        fs.unlink(templateData.attachments[0].path, (err) => {
            if (err) {
                console.error('Failed to delete file:', err);
            }
        });
        res.json({
            status: true,
            data: data
        });
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Template ID':e.message
        })
    }
})

module.exports = router;
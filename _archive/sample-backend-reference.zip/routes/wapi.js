const express = require('express');
const Lead = require('../models/leadModel');
const { annualComplianceId, doubletickApiKey } = require('../libs/common');
const { default: axios } = require('axios');
const Service = require('../models/serviceModel');
const router = express.Router();

router.post('/lead/compliance/cold', async(req, res)=>{
    try{
        let {name, phone, agent} = req.body;
        if(!name || !phone){
            throw new Error('Missing Data');
        }
        phone = String(phone).slice(-10);

        const leadData = await Lead.findOne({phone: phone, $or: [{ service: annualComplianceId }, { service: { $exists: false } }] });
        if(leadData){
            let obj = {type: 'cold', source: 'whatsapp', service: annualComplianceId, modified: Date.now()};
            if(agent && agent != ''){
                obj.assigned = agent
            }
            await Lead.findByIdAndUpdate(leadData.id, obj);
        }else{
            let obj = {
                name: name,
                phone: phone,
                companyName: '',
                source: 'whatsapp',
                type: 'cold',
                service: annualComplianceId
            }
            if(agent && agent != ''){
                obj.assigned = agent
            }

            await Lead.create(obj);
        }
        res.json({
            status: true
        })

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/lead/compliance/hot', async(req, res)=>{
    try{
        let {name, phone, agent} = req.body;
        if(!name || !phone){
            throw new Error('Missing Data');
        }
        phone = String(phone).slice(-10);

        const leadData = await Lead.findOne({phone: phone, $or: [{ service: annualComplianceId }, { service: { $exists: false } }] });
        if(leadData){
            let obj = {type: 'hot', source: 'whatsapp', service: annualComplianceId, modified: Date.now()};
            if(agent && agent != ''){
                obj.assigned = agent
            }
            await Lead.findByIdAndUpdate(leadData.id, obj);
        }else{
            let obj = {
                name: name,
                phone: phone,
                companyName: '',
                source: 'whatsapp',
                type: 'hot',
                service: annualComplianceId
            }
            if(agent && agent != ''){
                obj.assigned = agent
            }

            await Lead.create(obj);
        }
        res.json({
            status: true
        })

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/lead/service/cold', async(req, res)=>{
    try{
        let {name, phone, agent, service} = req.body;
        if(!name || !phone){
            throw new Error('Missing Data');
        }
        phone = String(phone).slice(-10);

        const serviceData = await Service.findById(service);
        if(!serviceData){
            throw new Error('Invalid Service ID');
        }

        const leadData = await Lead.findOne({phone: phone, $or: [{ service: serviceData.id }, { service: { $exists: false } }] });
        if(leadData){
            let obj = {type: 'cold', source: 'whatsapp', service: serviceData.id, modified: Date.now()};
            if(agent && agent != ''){
                obj.assigned = agent
            }
            await Lead.findByIdAndUpdate(leadData.id, obj);
        }else{
            let obj = {
                name: name,
                phone: phone,
                companyName: '',
                source: 'whatsapp',
                type: 'cold',
                service: serviceData.id
            }
            if(agent && agent != ''){
                obj.assigned = agent
            }

            await Lead.create(obj);
        }
        res.json({
            status: true
        })

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/lead/service/hot', async(req, res)=>{
    try{
        let {name, phone, agent, service} = req.body;
        if(!name || !phone){
            throw new Error('Missing Data');
        }
        phone = String(phone).slice(-10);

        const serviceData = await Service.findById(service);
        if(!serviceData){
            throw new Error('Invalid Service ID');
        }

        const leadData = await Lead.findOne({phone: phone, $or: [{ service: serviceData.id }, { service: { $exists: false } }] });
        if(leadData){
            let obj = {type: 'hot', source: 'whatsapp', service: serviceData.id, modified: Date.now()};
            if(agent && agent != ''){
                obj.assigned = agent
            }
            await Lead.findByIdAndUpdate(leadData.id, obj);
        }else{
            let obj = {
                name: name,
                phone: phone,
                companyName: '',
                source: 'whatsapp',
                type: 'hot',
                service: serviceData.id
            }
            if(agent && agent != ''){
                obj.assigned = agent
            }

            await Lead.create(obj);
        }
        res.json({
            status: true
        })

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/lead/cold', async(req, res)=>{
    try{
        let {contact, from} = req.body;
        const name = contact.name;
        const phone = String(from).slice(-10);
        if(!name || !phone){
            throw new Error('Missing Data');
        }

        const leadData = await Lead.findOne({phone: phone});
        if(!leadData){
            let obj = {
                name: name,
                phone: phone,
                companyName: '',
                source: 'whatsapp',
                type: 'cold'
            }

            await Lead.create(obj);
        }else{
            await Lead.findByIdAndUpdate(leadData.id, {modified: Date.now()});
        }
        res.json({
            status: true
        })

    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.get('/templates', async(req, res)=>{
    try{
        const resp = await axios.get("https://public.doubletick.io/v2/templates",{headers: {Accept: "application/json", Authorization: doubletickApiKey}});
        res.json({
            status: true,
            data: resp.data
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

module.exports = router;
const express = require('express');
const { userVerify } = require('../libs/auth');
const { getInvoice, generatePDF } = require('../libs/invoice');
const RecurringInvoiceItem = require('../models/recurringInvoiceItemModel');
const RecurringInvoice = require('../models/recurringInvoiceModel');
const Customer = require('../models/customerModel');
const Invoice = require('../models/invoiceModel');
const InvoiceItem = require('../models/invoiceItemsModel');
const Payment = require('../models/paymentModel');
const Config = require('../models/configModel');
const EmailTemplate = require('../models/emailTemplates');
const TemplateHistory = require('../models/templateHistory');
const moment = require('moment');
const { sendEmails } = require('../libs/email');
const { format } = require('@fast-csv/format');
const router = express.Router();

router.post('/lists/:page', userVerify, async(req, res)=>{
    try{
        const page = parseInt(req.params.page) || 1;
        if(!page){
            throw new Error('Missing Page Number');
        }
        if (Number.isNaN(page) || !Number.isInteger(page) || page < 1) {
            throw new Error('Invalid Page Number');
        }

        const {search, start, end, type, func, value} = req.body;

        const options = {
            page: page,
            limit: 50,
            sort: { _id: -1 },
            populate: [{path: 'customer', select: 'name companyName'},{path: 'linkedService', select: '_id', populate: {path: 'service', select: 'name'}}]
        };

        let query = {};
        if(search && search.trim() != ""){
            const regex = new RegExp(search, 'i');
            const matchingCustomers = await Customer.find({
                $or: [
                    { name: { $regex: regex } },
                    { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                    { companyName: { $regex: regex } }
                ]
            }).select('_id');

            const userIds = matchingCustomers.map(customer => customer._id);
            query.$or = [
                { customer: { $in: userIds } },
                { invoiceNo: regex}
            ]
        }
        if(start > 0 && end > 0 && end > start){
            query.invDate = { $gte: new Date(start), $lte: new Date(end) };
        }
        if (type && func && value !== "") {
            const allowedTypes = ["price", "gst", "total", "due"];
            const allowedFuncs = ["<=", "=", ">="];
        
            if (allowedTypes.includes(type) && allowedFuncs.includes(func)) {
                let condition = {};
                switch (func) {
                    case "<=":
                        condition = { $lte: parseFloat(value) };
                        break;
                    case "=":
                        condition = { $eq: parseFloat(value) };
                        break;
                    case ">=":
                        condition = { $gte: parseFloat(value) };
                        break;
                }
                query[type] = condition;
            }
        }

        const invoices = await Invoice.paginate(query, options);
        res.json({
            status: true,
            data: invoices
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.post('/listsrecurring/:page', userVerify, async(req, res)=>{
    try{
        const page = parseInt(req.params.page) || 1;
        if(!page){
            throw new Error('Missing Page Number');
        }
        if (Number.isNaN(page) || !Number.isInteger(page) || page < 1) {
            throw new Error('Invalid Page Number');
        }

        const {search, dtype, status, start, end} = req.body;

        let sort = { _id: -1 };
        if(dtype == "next"){
            sort = { nextDate: 1 };
        }

        const options = {
            page: page,
            limit: 50,
            sort: sort,
            populate: [{path: 'customer', select: 'name companyName incorporationDate'},{path: 'linkedService', select: '_id', populate: {path: 'service', select: 'name'}}]
        };

        let query = {};
        if(search && search.trim() != ""){
            const regex = new RegExp(search, 'i');
            const matchingCustomers = await Customer.find({
                $or: [
                    { name: { $regex: regex } },
                    { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                    { companyName: { $regex: regex } }
                ]
            }).select('_id');

            const userIds = matchingCustomers.map(customer => customer._id);
            query.customer = { $in: userIds } ;
        }
        if(start > 0 && end > 0 && end > start){
            const dateFieldMap = {
                "created": "created",
                "start": "startDate",
                "end": "endDate",
                "next": "nextDate"
            };
            const dateField = dateFieldMap[dtype];
            if (dateField) {
                query[dateField] = { $gte: new Date(start), $lte: new Date(end) };
            }
        }
        if(status == "Y"){
            query.status = true;
        }
        if(status == "N"){
            query.status = false;
        }

        const invoices = await RecurringInvoice.paginate(query, options);
        res.json({
            status: true,
            data: invoices
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.get('/listsrecurringcsv', userVerify, async(req, res)=>{
    try{
        const data = JSON.parse(req.query.data);

        const {search, dtype, status, start, end} = data;

        let sort = { _id: -1 };
        if(dtype == "next"){
            sort = { nextDate: 1 };
        }

        let query = {};
        if(search && search.trim() != ""){
            const regex = new RegExp(search, 'i');
            const matchingCustomers = await Customer.find({
                $or: [
                    { name: { $regex: regex } },
                    { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                    { companyName: { $regex: regex } }
                ]
            }).select('_id');

            const userIds = matchingCustomers.map(customer => customer._id);
            query.customer = { $in: userIds } ;
        }
        if(start > 0 && end > 0 && end > start){
            const dateFieldMap = {
                "created": "created",
                "start": "startDate",
                "end": "endDate",
                "next": "nextDate"
            };
            const dateField = dateFieldMap[dtype];
            if (dateField) {
                query[dateField] = { $gte: new Date(start), $lte: new Date(end) };
            }
        }
        if(status == "Y"){
            query.status = true;
        }
        if(status == "N"){
            query.status = false;
        }

        const invoices = await RecurringInvoice.find(query).populate([{path: 'customer', select: 'name phone companyName type'},{path: 'linkedService', select: '_id', populate: {path: 'service', select: 'name'}}]).sort(sort);

        res.setHeader('Content-Disposition', 'attachment; filename="recurringInvoices.csv"');
        res.setHeader('Content-Type', 'text/csv');
        const csvStream = format({ headers: true });
        csvStream.pipe(res); 

        for(const invoice of invoices){
            csvStream.write({created: moment(invoice.created).utcOffset("+05:30").format('DD/MM/YYYY hh:mm a'), customerName: invoice.customer.name, customerPhone: invoice.customer.phone, customerCompany: invoice.customer.companyName, companyType: invoice.customer.type, incorporationDate: moment(invoice.customer.incorporationDate).format('DD/MM/YYYY'), LinkedService: invoice.linkedService ? invoice.linkedService.service.name : '', startDate: moment(invoice.startDate).utcOffset("+05:30").format('DD/MM/YYYY'), endDate: moment(invoice.endDate).utcOffset("+05:30").format('DD/MM/YYYY'), nextDate: invoice.nextDate?moment(invoice.nextDate).utcOffset("+05:30").format('DD/MM/YYYY'):'', interval: invoice.interval, intervalType: invoice.intervalType, status: invoice.status ? 'Active' : 'Inactive'});
        }

        csvStream.end();
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.post('/payments/:page', userVerify, async(req, res)=>{
    try{
        const page = parseInt(req.params.page) || 1;
        if(!page){
            throw new Error('Missing Page Number');
        }
        if (Number.isNaN(page) || !Number.isInteger(page) || page < 1) {
            throw new Error('Invalid Page Number');
        }

        const {search, start, end, type} = req.body;

        const options = {
            page: page,
            limit: 50,
            sort: { _id: -1 },
            populate: [{path: 'customer', select: 'name companyName'},{path: 'invoice', select: 'invoiceNo'}]
        };

        let query = {};
        if(search && search.trim() != ""){
            const regex = new RegExp(search, 'i');
            const matchingCustomers = await Customer.find({
                $or: [
                    { name: { $regex: regex } },
                    { $expr: { $regexMatch: { input: { $toString: '$phone' }, regex: regex } } },
                    { companyName: { $regex: regex } }
                ]
            }).select('_id');

            const userIds = matchingCustomers.map(customer => customer._id);

            const matchingInvoices = await Invoice.find({invoiceNo: { $regex: regex }}).select('_id');

            const invoiceIds = matchingInvoices.map(invoice => invoice._id);

            query.$or = [
                { customer: { $in: userIds } },
                { invoice: { $in: invoiceIds}}
            ]
        }
        if(start > 0 && end > 0 && end > start){
            query.payDate = { $gte: new Date(start), $lte: new Date(end) };
        }
        if (type && Array.isArray(type) && type.length > 0) {
            query.payType = { $in: type };
        }

        const payments = await Payment.paginate(query, options);
        res.json({
            status: true,
            data: payments
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.get('/details/:id', userVerify, async(req, res)=>{
    try{
        const data = await Invoice.findById(req.params.id).populate({path: 'customer', select: 'name companyName phone emails address gst', populate:{path: 'state'}});

        const items = await InvoiceItem.find({invoice: data.id}).populate({path: 'product', select: 'hsn'});

        const payments = await Payment.find({invoice: data.id}).select('payType amount note payDate');

        const template = await Config.findOne({name: 'invoiceTemplate'});
        const emailTemplate = await EmailTemplate.findById(template.value).select('content subject');

        res.json({
            status: true,
            data: data,
            items: items,
            payments: payments,
            emailTemplate: emailTemplate
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Invoice ID':e.message
        })
    }
})

router.get('/recurringdetails/:id', userVerify, async(req, res)=>{
    try{
        const data = await RecurringInvoice.findById(req.params.id).populate({path: 'customer', select: 'name companyName phone emails address gst', populate:{path: 'state'}});

        const items = await RecurringInvoiceItem.find({invoice: data.id}).populate({path: 'product', select: 'name hsn'});

        const invoices = await Invoice.find({recurring: data.id}).select('invDate invoiceNo price gst total due');

        res.json({
            status: true,
            data: data,
            items: items,
            invoices: invoices
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Invoice ID':e.message
        })
    }
})

router.get('/customers', userVerify, async(req, res)=>{
    try{
        const customers = await Customer.find({}).select('name companyName').sort({name: 1});
        res.json({
            status: true,
            data: customers
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
})

router.post('/add', userVerify, async(req, res)=>{
    try{
        const {cid, invDate, items, recurring, end, interval, intervalType} = req.body;
        if(!cid || !items || items.length < 1 || !invDate){
            throw new Error('Missing Data');
        }

        if(!recurring){
            const result = await getInvoice(cid, invDate, items, null, null);

            if(!result.status){
                throw new Error(result.message);
            }

        }else{
            if(!interval || !intervalType || !end){
                throw new Error('Missing Data');
            }

            const startDate = new Date(invDate);
            startDate.setHours(0, 0, 0, 0);
            const endDate = new Date(end);
            endDate.setHours(0, 0, 0, 0);

            const nextDate = new Date(startDate);
            if (intervalType === "day") {
                nextDate.setDate(nextDate.getDate() + parseInt(interval));
            } else if (intervalType === "month") {
                nextDate.setMonth(nextDate.getMonth() + parseInt(interval));
            }

            const today = new Date();
            today.setHours(0, 0, 0, 0);

            if (nextDate < today) {
                throw new Error("Start Date is too old for given interval.");
            }
            if (nextDate > endDate) {
                throw new Error("End Date is before next invoice date.");
            }

            const invoiceData = await RecurringInvoice.create({customer: cid, startDate: startDate, endDate: endDate, nextDate: nextDate, interval: interval, intervalType: intervalType});

            const invItems = [];
            for(let i=0; i<items.length; i++){
                if(!items[i].product || !items[i].professional || isNaN(items[i].govt) || isNaN(items[i].gst)){
                    throw new Error('Missing Recurring Items Data');
                }
                let invItem = {
                    customer: cid,
                    invoice: invoiceData.id,
                    product: items[i].product,
                    professional: items[i].professional,
                    govt: items[i].govt,
                    gst: items[i].gst
                };
                invItems.push(invItem);
            }
            await RecurringInvoiceItem.insertMany(invItems);

            if(startDate <= today){
                const result = await getInvoice(cid, startDate, items, invoiceData.id, null);

                if(!result.status){
                    throw new Error(result.message);
                }
            }
        }

        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

router.post('/payment', userVerify, async(req, res)=>{
    try{
        const {id, payType, amount, note, payDate} = req.body;
        if(!id || !payDate || !payDate || isNaN(amount) || amount <= 0){
            throw new Error('Missing data');
        }
        const invoiceData = await Invoice.findById(id).select('customer due');
        if(!invoiceData){
            throw new Error('Invoice not found');
        }
        if(invoiceData.due < amount){
            throw new Error('Entered amount is greater than Due Amount');
        }
        await Payment.create({customer: invoiceData.customer, invoice: id, payType, amount, note, payDate: new Date(payDate)});
        await Invoice.findByIdAndUpdate(id, { $inc: { due: -amount } });
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Invoice ID':e.message
        })
    }
})

router.post('/deletepayment', userVerify, async(req, res)=>{
    try{
        const {id, pid} = req.body;
        if(!id || !pid){
            throw new Error('Missing data');
        }
        const paymentData = await Payment.findById(pid).select('amount');
        if(!paymentData){
            throw new Error('Payment not found');
        }

        await Invoice.findByIdAndUpdate(id, { $inc: { due: paymentData.amount } });
        await Payment.deleteOne({_id: pid});
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Payment or Invoice ID':e.message
        })
    }
})

router.post('/deleteinvoice', userVerify, async(req, res)=>{
    try{
        const {id} = req.body;
        if(!id){
            throw new Error('Missing data');
        }
        const invoiceData = await Invoice.findById(id).select('_id');
        if(!invoiceData){
            throw new Error('Invoice not found');
        }

        await InvoiceItem.deleteMany({invoice: id});
        await Payment.deleteMany({invoice: id});
        await Invoice.deleteOne({_id: id});

        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Invoice ID':e.message
        })
    }
})

router.post('/recurringstatus', userVerify, async(req, res)=>{
    try{
        const {id, status} = req.body;
        if(!id){
            throw new Error('Missing data');
        }
        await RecurringInvoice.findByIdAndUpdate(id, {status})
        res.json({
            status: true
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Recurring Invoice ID':e.message
        })
    }
})

router.post('/sendemail', userVerify, async(req, res)=>{
    try{
        let {id, content, subject} = req.body;
        if(!id || !content || !subject){
            throw new Error('Missing Data');
        }
        const invoiceData = await Invoice.findById(id);
        if(!invoiceData){
            throw new Error('Invoice not found');
        }
        const template = await Config.findOne({name: "invoiceTemplate"});

        const customerData = await Customer.findById(invoiceData.customer).populate('state');
        if(!customerData){
            throw new Error('Invalid Customer');
        }
        const emails = customerData.emails;
        if(!emails || emails.length == 0){
            throw new Error('No emails added to this customer');
        }

        subject = subject.replace(/{{name}}/g, customerData.name);
        subject = subject.replace(/{{companyName}}/g, customerData.companyName);
        subject = subject.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
        subject = subject.replace(/{{invoiceNo}}/g, invoiceData.invoiceNo);
        subject = subject.replace(/{{invoiceDate}}/g, moment(invoiceData.invDate).format('Do MMM YYYY'));
        subject = subject.replace(/{{invoiceAmount}}/g, "₹ "+parseFloat(invoiceData.total).toFixed(2));

        content = content.replace(/{{name}}/g, customerData.name);
        content = content.replace(/{{companyName}}/g, customerData.companyName);
        content = content.replace(/{{address}}/g, customerData.address.replace(/\n/g, " "));
        content = content.replace(/{{invoiceNo}}/g, invoiceData.invoiceNo);
        content = content.replace(/{{invoiceDate}}/g, moment(invoiceData.invDate).format('Do MMM YYYY'));
        content = content.replace(/{{invoiceAmount}}/g, "₹ "+parseFloat(invoiceData.total).toFixed(2));

        await TemplateHistory.create({customer: invoiceData.customer, type: "customer", content: content, subject: subject, template: template.value});

        res.json({
            status: true
        })
        const templateData = await EmailTemplate.findById(template.value).select('attachments');
        const invoiceItems = await InvoiceItem.find({invoice: invoiceData.id}).populate({path: 'product', select: 'hsn'});
        const pdfBuffer = await generatePDF(customerData, invoiceData, invoiceItems);
        let eobj =  {
            filename: invoiceData.invoiceNo+'.pdf',
            content: pdfBuffer, 
            contentType: 'application/pdf'
        }
        await sendEmails(emails, subject, content, templateData.attachments, eobj);
    }catch(e){
        res.json({ 
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})  

router.get('/download/:id', async (req, res) => {
    try {
        const invoiceData = await Invoice.findById(req.params.id);
        if(!invoiceData){
            throw new Error('Invalid Invoice ID');
        }
        const customerData = await Customer.findById(invoiceData.customer).populate('state');
        const invoiceItems = await InvoiceItem.find({invoice: invoiceData.id}).populate({path: 'product', select: 'hsn'});
        const pdfBuffer = await generatePDF(customerData, invoiceData, invoiceItems);
        
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'attachment; filename="'+invoiceData.invoiceNo+'.pdf"');
        res.end(Buffer.from(pdfBuffer));
    } catch (e) {
        res.status(500).json({
            status: false,
            message: e.name === 'CastError' ? 'Invalid Invoice ID' : e.message,
        });
    }
});

router.get('/view/:id', async (req, res) => {
    try {
        const invoiceData = await Invoice.findById(req.params.id);
        if(!invoiceData){
            throw new Error('Invalid Invoice ID');
        }
        const customerData = await Customer.findById(invoiceData.customer).populate('state');
        const invoiceItems = await InvoiceItem.find({invoice: invoiceData.id}).populate({path: 'product', select: 'hsn'});
        const pdfBuffer = await generatePDF(customerData, invoiceData, invoiceItems);
        
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'inline; filename="'+invoiceData.invoiceNo+'.pdf"');
        res.end(pdfBuffer);
    } catch (e) {
        res.status(500).json({
            status: false,
            message: e.name === 'CastError' ? 'Invalid Invoice ID' : e.message,
        });
    }
});

module.exports = router;
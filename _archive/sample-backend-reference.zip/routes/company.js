const express = require('express');
const { customerVerify } = require('../libs/auth');
const Customer = require('../models/customerModel');
const Compliance = require('../models/complianceModel');
const Invoice = require('../models/invoiceModel');
const router = express.Router();

router.get('/details', customerVerify, async(req, res)=>{
    try{
        const customerData = await Customer.findById(req.userid).select('name companyName compliance').populate('financialYear');
        if(!customerData){
            throw new Error("Invalid Customer");
        }
        res.json({
            status: true, 
            data: customerData
        })
    }catch(e){
        res.json({ 
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
})

router.post('/compliances', customerVerify, async(req, res)=>{
    try{
        const {fy} = req.body;
        if(!fy){
            throw new Error('Missing Data');
        }
        const customerData = await Customer.findById(req.userid);
        if(!customerData){
            throw new Error('Invalid Customer');
        }

        const complianceData = await Compliance.find({customer: customerData.id, financialYear: fy}).select('status doneOn').populate({path: 'compliance', select: 'name expiry'});

        res.json({
            status: true,
            data: complianceData
        })
    }catch(e){
        res.json({
            status: false,
            message: e.name == "CastError"?'Invalid Customer ID':e.message
        })
    }
});

router.get('/invoices', customerVerify, async(req, res)=>{
    try{
        const invoices = await Invoice.find({customer: req.userid}).sort({invDate: -1}).sort({invDate: -1, _id: -1}).populate({path: 'linkedService', select: '_id', populate: {path: 'service', select: 'name'}});

        res.json({
            status: true,
            data: invoices
        })
    }catch(e){
        res.json({
            status: false,
            message: e.message
        })
    }
});

module.exports = router;